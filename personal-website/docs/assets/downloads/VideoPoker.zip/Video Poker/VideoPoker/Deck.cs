﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace VideoPoker
{
    /// <summary>
    /// Deck class defines a working set of playing cards with suits and face values
    /// </summary>
    //Deck class defines a working set of playing cards with suits and face values
    class Deck
    {
        public const int SIZE = 52;
        public const int CARDS_PER_SUIT = 13;
        public const int SUITS_IN_DECK = 4;
        private Card[] _deckOfCards;
        /// <summary>
        /// Default Constructor initializes the array that represents the deck of cards
        /// </summary>
        //Default Constructor initializes the array that represents the deck of cards
        public Deck()
        {
            _deckOfCards = new Card[SIZE];
            Initialize();
            Generate();
        }

 
        /// <summary>
        /// Method takes no arguments. Prepares the card array by initializing each item using its default constructor. Returns void
        /// </summary>
        //Method takes no arguments. Prepares the card array by initializing each item using its default constructor. Returns void
        private void Initialize()
        {
            for(int i=0; i<SIZE;i++)
            {
                _deckOfCards[i] = new Card();
            }
        }

        /// <summary>
        /// Method takes no arguments. Generates each card's information, including the card's suit, value, and face if it is a face card. Returns void
        /// </summary>
        //Method takes no arguments. Generates each card's information, including the card's suit, value, and face if it is a face card. Returns void
        private void Generate()
        {
            int relativeCounter = 0; //indicates relative position in the deck (ace(1) to king (13))
            int absoluteCounter; //indicates absolute position in the deck (card 1 to card 52)

            for (absoluteCounter = 0; absoluteCounter < SIZE; absoluteCounter++) //loop assigns relative deck position (ace: 1, king: 13)
            {
                _deckOfCards[absoluteCounter].CardNumber = relativeCounter + 1;
                relativeCounter++;

                if(relativeCounter >= (int)FaceEnumerator.Jack) //checks if the card is a face card, assigns the face string is necessary
                    _deckOfCards[absoluteCounter].CardFace = ((FaceEnumerator)relativeCounter).ToString();

                if (relativeCounter == CARDS_PER_SUIT) //resets relative counter and starts over
                    relativeCounter = 0;
            }

            absoluteCounter = 0;
            for (int suitGenCounter = 0; suitGenCounter < SUITS_IN_DECK; suitGenCounter++) //dual loop assigns the suit of each card in the deck
            {
                for (relativeCounter = 0; relativeCounter < CARDS_PER_SUIT; relativeCounter++)
                {
                    _deckOfCards[absoluteCounter].CardSuit = ((SuitsEnumerator)suitGenCounter).ToString();
                    absoluteCounter++;
                }
            }
        }

        /// <summary>
        /// Method takes no arguments. Shuffles all of the cards in the deck. Returns void.
        /// </summary>
        //Method takes no arguments. Shuffles all of the cards in the deck. Returns void.
        public void Shuffle()
        {
         
            Random rnd = new Random();
            int deckPlacementValue;
            int[] deckPositions = new int[SIZE];
            int posIndex = 0;
            while (posIndex < SIZE) //loop gives every card a random associated index
            {
                deckPlacementValue = rnd.Next(0, SIZE + 1);

                if (!deckPositions.Contains(deckPlacementValue))
                {
                    deckPositions[posIndex] = deckPlacementValue;
                    posIndex++;
                }
            }


            
            for (int i=0; i < SIZE; i++) //loop takes the randomly ordered numbers generated and stores them in the deck object itself. In the process, resets all "Used" to false
            {
                _deckOfCards[i].DeckPosition = deckPositions[i];
                _deckOfCards[i].Used = false;
            }

            for (int write = 0; write < SIZE; write++) //bubble sorts the cards by the random number generated previously. The result is a shuffled deck.
                for (int sort = 0; sort < SIZE - 1; sort++)
                    if (_deckOfCards[sort].DeckPosition > _deckOfCards[sort + 1].DeckPosition)
                        ShuffleSwap(sort, sort + 1);

        }
        
        /// <summary>
        /// Takes two indexes and swaps their positions within the deck. Returns void
        /// </summary>
        /// <param name="index1"></param>
        /// <param name="index2"></param>
        // Takes two indexes and swaps their positions within the deck. Returns void.
        private void ShuffleSwap(int index1, int index2)
        {
            Card temp = _deckOfCards[index1];
            _deckOfCards[index1] = _deckOfCards[index2];
            _deckOfCards[index2] = temp;
        }

        /// <summary>
        /// EXPERIMENTAL METHOD!!! DO NOT USE IN FINAL SUBMISSION!! Generates new hand (array of Cards) and returns it
        /// </summary>
        /// <returns></returns>
        //EXPERIMENTAL METHOD!!! DO NOT USE IN FINAL SUBMISSION!! Generates new hand (array of Cards) and returns it
        public Card[] GenerateNewHand()
        {
            Card[] hand = new Card[Card.HAND_SIZE];

            for(int i=0; i < Card.HAND_SIZE; i++)
            {
                _deckOfCards[i].Used = true;
                hand[i] = _deckOfCards[i];
            }

            return hand;
        }

        /// <summary>
        /// Receives a deck index in the form of an int and returns a card with the index that it is passed
        /// </summary>
        /// <param name="indexToGet"></param>
        /// <returns></returns>
        //Receives a deck index in the form of an int and returns a card that is then swapped in the hand while flagging it as used
        public Card GetCard(int indexToGet)
        {
            if (_deckOfCards[indexToGet].Used)
                throw new InvalidOperationException("ERROR: CANNOT USE A CARD THAT WAS ALREADY USED");
            
            _deckOfCards[indexToGet].Used = true;
            return _deckOfCards[indexToGet];
        }

        /// <summary>
        /// Override returns the names of every card in the deck in their current order
        /// </summary>
        /// <returns></returns>
        //Override returns the names of every card in the deck in their current order
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < SIZE; i++)
            {
                sb.AppendLine(_deckOfCards[i].ToString());
            }
            return sb.ToString();
        }

        #region//ENUMERATORS
        /// <summary>
        /// Enumerator stores the suits of the deck as integers
        /// </summary>
        //Enumerator stores the suits of the deck as integers
        public enum SuitsEnumerator
        {
            Diamonds,
            Hearts,
            Clubs,
            Spades
        }

        /// <summary>
        /// Enumerator stores the faces of the deck as integers
        /// </summary>
        //Enumerator stores the faces of the deck as integers
        public enum FaceEnumerator
        {
            Jack = 11,
            Queen, //12
            King, //13
        }
        #endregion
    }//end of class
}//end of namespace
