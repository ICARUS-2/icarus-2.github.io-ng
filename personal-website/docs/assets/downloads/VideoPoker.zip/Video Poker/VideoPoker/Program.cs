﻿using System;
using System.Text;
using System.Linq;
using static System.Console;

namespace VideoPoker
{
    /// <summary>
    /// Program uses the Card class and the Deck class in order to simulate a game of 5-Card Draw Poker
    /// Testers: George Briffett
    /// </summary>
    //Program uses the Card class and the Deck class in order to simulate a game of 5-Card Draw Poker
    class Program
    {
        #region//Menu Selector Constancts
        //main menu
        const char MENU_SELECT_PLAY = '1';
        const char MENU_SELECT_TEST = '2';
        const char MENU_SELECT_EXIT = '3';
        //test menu
        const char TEST_SELECT_ROYAL_FLUSH = '1';
        const char TEST_SELECT_STRAIGHT_FLUSH = '2';
        const char TEST_SELECT_FOUR_OF_A_KIND = '3';
        const char TEST_SELECT_FULL_HOUSE = '4';
        const char TEST_SELECT_FLUSH = '5';
        const char TEST_SELECT_STRAIGHT = '6';
        const char TEST_SELECT_THREE_OF_A_KIND = '7';
        const char TEST_SELECT_TWO_PAIR = '8';
        const char TEST_SELECT_PAIR = '9';
        const char TEST_SELECT_RETURN = '0';
        #endregion

        const int BET_MIN = 1;
        const int CARD_REPLACE_MAX = 4;
        const int AMOUNT_IN_PAIR = 2;
        const int AMOUNT_OF_PAIRS_IN_2PAIR = 2;
        const int AMOUNT_IN_THREE_OF_A_KIND = 3;
        const int AMOUNT_IN_FOUR_OF_A_KIND = 4;
        const int ACE_HIGH_VALUE = 14;
        const int ROYAL_MIN = 10;
        const int START_AMOUNT = 1000;

        /// <summary>
        /// Main method contains the primary game loop that is starting a new round, asking the user for their inputs and displaying the results
        /// </summary>
        /// <param name="args"></param>
        //Main method contains the primary game loop that is starting a new round, asking the user for their inputs and displaying the results
        static void Main(string[] args)
        {
            Deck deck = new Deck();
            Card[] hand = null;
            int bankrollAmount;
            int betAmount = 0; 
            //Card[] hand = new Card[5];
            bool exit = false;
            bool gameRunning = true;
               
            #region//TEST HAND
            /*
            hand[0] = new Card();
            hand[1] = new Card();
            hand[2] = new Card();
            hand[3] = new Card();
            hand[4] = new Card();

            hand[0].CardFace = null;
            hand[0].CardNumber = 1;
            hand[0].CardSuit = "Hearts";

            hand[1].CardFace = null;
            hand[1].CardNumber = 3;
            hand[1].CardSuit = "Spades";

            hand[2].CardFace = null;
            hand[2].CardNumber = 1;
            hand[2].CardSuit = "Spades";

            hand[3].CardFace = null;
            hand[3].CardNumber = 6;
            hand[3].CardSuit = "Clubs";

            hand[4].CardFace = null;
            hand[4].CardNumber = 6;
            hand[4].CardSuit = "Hearts";*/
            #endregion


            while (!exit)
            {
                MainMenu();
                gameRunning = true;
                bankrollAmount = START_AMOUNT;
                while (gameRunning)
                {
                    NewRound(hand, deck, ref bankrollAmount, ref betAmount);
                    
                    if (bankrollAmount == 0)
                    {
                        //Clear();
                        exit = GameOverScreen();
                        break;
                    }

                    gameRunning = RoundEndScreen(bankrollAmount);
                    ResetColor();
                }//end of game loop
            }//end of outer loop
        }//end of main

        #region//MAIN TOP-LEVEL METHODS (some used deeper in program)
        /// <summary>
        /// Takes no parameters, returns void. The main menu screen displays the options to play, test, and exit. Input method is ReadKey()
        /// </summary>
        //The main menu screen displays the options to play, test, and exit. Input method is ReadKey()
        static void MainMenu()
        {
            char userKeyPress = '-';
            while (userKeyPress != MENU_SELECT_PLAY)
            {
                WriteLine("----------VIDEO POKER----------");
                WriteLine("\nSELECT OPTION");
                WriteLine("\n1 - Play");
                WriteLine("\n2 - Testing Mode");
                WriteLine("\n3 - Exit Game");


                userKeyPress = ReadKey(true).KeyChar;

                switch (userKeyPress)
                {
                    case MENU_SELECT_PLAY:
                        break; //so it doesnt trigger the error message

                    case MENU_SELECT_TEST:
                        Clear();
                        TestingMode();
                        break;

                    case MENU_SELECT_EXIT:
                        Environment.Exit(0);
                        break;

                    default:
                        Clear();
                        ForegroundColor = ConsoleColor.Red;
                        WriteLine("Error: Input can only be one of the numbered options below");
                        ResetColor();
                        break;
                }
            }
        }

        /// <summary>
        /// Takes no parameters, returns void. Testing mode method provides a scope in which all hand detection testing can be safely done without interfering with the main part of the game. Returns void
        /// </summary>
        //Testing mode method provides a scope in which all hand detection testing can be safely done without interfering with the main part of the game. Returns void.
        static void TestingMode()
        {
            char userKeyPress = '-';
            Card[] testingHand = new Card[Card.HAND_SIZE];
            Deck testingDeck = new Deck();
            int testingBankroll = 0;
            int testingBetAmount = 0;
            for (int i=0; i < testingHand.Length; i++)
            {
                testingHand[i] = new Card();
            }
            while (userKeyPress != TEST_SELECT_RETURN)
            {
                WriteLine("----------TESTING MODE----------");
                WriteLine("\nSELECT AN OPTION");
                WriteLine("1 - Test Royal Flush");
                WriteLine("2 - Test Straight Flush");
                WriteLine("3 - Test Four-Of-A-Kind");
                WriteLine("4 - Test Full House");
                WriteLine("5 - Test Flush");
                WriteLine("6 - Test Straight");
                WriteLine("7 - Test Three-Of-A-Kind");
                WriteLine("8 - Test 2 Pair");
                WriteLine("9 - Test Pair");
                WriteLine("0 - Return To Main Menu");

                userKeyPress = ReadKey(true).KeyChar;

                Clear();
                switch (userKeyPress)
                {
                    
                    case TEST_SELECT_ROYAL_FLUSH: //royal flush
                        WriteLine("Testing Royal Flush");
                        testingHand[0].CardFace = null;
                        testingHand[0].CardNumber = 10;
                        testingHand[0].CardSuit = "Hearts";

                        testingHand[1].CardFace = "Jack";
                        testingHand[1].CardNumber = 11;
                        testingHand[1].CardSuit = "Hearts";

                        testingHand[2].CardFace = "Queen";
                        testingHand[2].CardNumber = 12;
                        testingHand[2].CardSuit = "Hearts";

                        testingHand[3].CardFace = "King";
                        testingHand[3].CardNumber = 13;
                        testingHand[3].CardSuit = "Hearts";

                        testingHand[4].CardFace = null;
                        testingHand[4].CardNumber = 1;
                        testingHand[4].CardSuit = "Hearts";
                        break;

                    case TEST_SELECT_STRAIGHT_FLUSH: //straight flush
                        WriteLine("Testing Straight Flush");
                        testingHand[0].CardFace = null;
                        testingHand[0].CardNumber = 1;
                        testingHand[0].CardSuit = "Hearts";

                        testingHand[1].CardFace = null;
                        testingHand[1].CardNumber = 2;
                        testingHand[1].CardSuit = "Hearts";

                        testingHand[2].CardFace = null;
                        testingHand[2].CardNumber = 3;
                        testingHand[2].CardSuit = "Hearts";

                        testingHand[3].CardFace = null;
                        testingHand[3].CardNumber = 4;
                        testingHand[3].CardSuit = "Hearts";

                        testingHand[4].CardFace = null;
                        testingHand[4].CardNumber = 5;
                        testingHand[4].CardSuit = "Hearts";
                        break;

                    case TEST_SELECT_FOUR_OF_A_KIND: //four of a kind
                        WriteLine("Testing Four-Of-A-Kind");
                        testingHand[0].CardFace = null;
                        testingHand[0].CardNumber = 1;
                        testingHand[0].CardSuit = "Hearts";

                        testingHand[1].CardFace = null;
                        testingHand[1].CardNumber = 1;
                        testingHand[1].CardSuit = "Clubs";

                        testingHand[2].CardFace = null;
                        testingHand[2].CardNumber = 1;
                        testingHand[2].CardSuit = "Diamonds";

                        testingHand[3].CardFace = null;
                        testingHand[3].CardNumber = 1;
                        testingHand[3].CardSuit = "Spades";

                        testingHand[4].CardFace = null;
                        testingHand[4].CardNumber = 2;
                        testingHand[4].CardSuit = "Hearts";
                        break;

                    case TEST_SELECT_FULL_HOUSE: //full house
                        WriteLine("Testing Full House");
                        testingHand[0].CardFace = null;
                        testingHand[0].CardNumber = 1;
                        testingHand[0].CardSuit = "Hearts";

                        testingHand[1].CardFace = null;
                        testingHand[1].CardNumber = 1;
                        testingHand[1].CardSuit = "Clubs";

                        testingHand[2].CardFace = null;
                        testingHand[2].CardNumber = 3;
                        testingHand[2].CardSuit = "Diamonds";

                        testingHand[3].CardFace = null;
                        testingHand[3].CardNumber = 3;
                        testingHand[3].CardSuit = "Spades";

                        testingHand[4].CardFace = null;
                        testingHand[4].CardNumber = 3;
                        testingHand[4].CardSuit = "Hearts";
                        break;
                        
                    case TEST_SELECT_FLUSH: //flush
                        WriteLine("Testing Flush");
                        testingHand[0].CardFace = null;
                        testingHand[0].CardNumber = 1;
                        testingHand[0].CardSuit = "Hearts";

                        testingHand[1].CardFace = null;
                        testingHand[1].CardNumber = 4;
                        testingHand[1].CardSuit = "Hearts";

                        testingHand[2].CardFace = null;
                        testingHand[2].CardNumber = 7;
                        testingHand[2].CardSuit = "Hearts";

                        testingHand[3].CardFace = null;
                        testingHand[3].CardNumber = 8;
                        testingHand[3].CardSuit = "Hearts";

                        testingHand[4].CardFace = null;
                        testingHand[4].CardNumber = 10;
                        testingHand[4].CardSuit = "Hearts";
                        break;

                    case TEST_SELECT_STRAIGHT: //straight
                        WriteLine("Testing Straight");
                        testingHand[0].CardFace = null;
                        testingHand[0].CardNumber = 1;
                        testingHand[0].CardSuit = "Hearts";

                        testingHand[1].CardFace = null;
                        testingHand[1].CardNumber = 2;
                        testingHand[1].CardSuit = "Clubs";

                        testingHand[2].CardFace = null;
                        testingHand[2].CardNumber = 3;
                        testingHand[2].CardSuit = "Hearts";

                        testingHand[3].CardFace = null;
                        testingHand[3].CardNumber = 4;
                        testingHand[3].CardSuit = "Hearts";

                        testingHand[4].CardFace = null;
                        testingHand[4].CardNumber = 5;
                        testingHand[4].CardSuit = "Hearts";
                        break;

                    case TEST_SELECT_THREE_OF_A_KIND: //3 of a kind
                        WriteLine("Testing Three Of A Kind");
                        testingHand[0].CardFace = null;
                        testingHand[0].CardNumber = 1;
                        testingHand[0].CardSuit = "Hearts";

                        testingHand[1].CardFace = null;
                        testingHand[1].CardNumber = 1;
                        testingHand[1].CardSuit = "Clubs";

                        testingHand[2].CardFace = null;
                        testingHand[2].CardNumber = 1;
                        testingHand[2].CardSuit = "Diamonds";

                        testingHand[3].CardFace = null;
                        testingHand[3].CardNumber = 2;
                        testingHand[3].CardSuit = "Hearts";

                        testingHand[4].CardFace = null;
                        testingHand[4].CardNumber = 3;
                        testingHand[4].CardSuit = "Hearts";
                        break;

                    case TEST_SELECT_TWO_PAIR: //2 pair
                        WriteLine("Testing Two Pair");
                        testingHand[0].CardFace = null;
                        testingHand[0].CardNumber = 1;
                        testingHand[0].CardSuit = "Hearts";

                        testingHand[1].CardFace = null;
                        testingHand[1].CardNumber = 1;
                        testingHand[1].CardSuit = "Clubs";

                        testingHand[2].CardFace = null;
                        testingHand[2].CardNumber = 2;
                        testingHand[2].CardSuit = "Diamonds";

                        testingHand[3].CardFace = null;
                        testingHand[3].CardNumber = 2;
                        testingHand[3].CardSuit = "Hearts";

                        testingHand[4].CardFace = null;
                        testingHand[4].CardNumber = 3;
                        testingHand[4].CardSuit = "Hearts";
                        break;

                    case TEST_SELECT_PAIR: //pair
                        WriteLine("Testing Pair");
                        testingHand[0].CardFace = null;
                        testingHand[0].CardNumber = 1;
                        testingHand[0].CardSuit = "Hearts";

                        testingHand[1].CardFace = null;
                        testingHand[1].CardNumber = 1;
                        testingHand[1].CardSuit = "Clubs";

                        testingHand[2].CardFace = null;
                        testingHand[2].CardNumber = 2;
                        testingHand[2].CardSuit = "Diamonds";

                        testingHand[3].CardFace = null;
                        testingHand[3].CardNumber = 4;
                        testingHand[3].CardSuit = "Hearts";

                        testingHand[4].CardFace = null;
                        testingHand[4].CardNumber = 3;
                        testingHand[4].CardSuit = "Hearts";
                        break;
                }
                if (int.TryParse(userKeyPress.ToString(), out int numPress) && userKeyPress != TEST_SELECT_RETURN)
                {
                    testingBankroll = START_AMOUNT;
                    TestingRound(testingHand, testingDeck, ref testingBankroll, ref testingBetAmount);
                    WriteLine("Press any key to return to test menu");
                    ReadKey();
                    Clear();
                }
                else
                {
                    ForegroundColor = ConsoleColor.Red;
                    WriteLine("Error: Input can only be one of the numbered options below");
                    ResetColor();
                }
            }
            Clear();
        }

        /// <summary>
        /// Method receives the hand, deck, bankroll and bet. Contains all of the sub-methods necessary to play one round of the game. Returns void
        /// </summary>
        /// <param name="hand"></param>
        /// <param name="deck"></param>
        /// <param name="bankrollAmount"></param>
        /// <param name="betAmount"></param>
        //Method receives the hand, deck, bankroll and bet. Contains all of the sub-methods necessary to play one round of the game.
        static void NewRound(Card[] hand, Deck deck, ref int bankrollAmount, ref int betAmount)
        {
            Clear();
            deck.Shuffle();
            hand = GenerateNewHand(deck);
            //hand = deck.GenerateNewHand();

            WriteLine("Your bankroll is ${0}", bankrollAmount);
            WriteLine("Please enter your bet");
            betAmount = ValInt(BET_MIN, bankrollAmount, String.Format("ERROR: BET CAN ONLY BE BETWEEN {0} AND {1}",BET_MIN, bankrollAmount));
            bankrollAmount -= betAmount;
            DisplayCurrentStats(bankrollAmount, betAmount);
            DisplayCurrentHand(hand);
            ProcessResult(hand, deck, ref bankrollAmount, ref betAmount);
        }

        /// <summary>
        /// Receives a deck and generates a new hand in the form of an array of cards from that deck and then returns the hand. Proper version of the GenerateNewHand found in the Deck class
        /// </summary>
        /// <param name="deck"></param>
        /// <returns></returns>
        //Receives a deck and generates a new hand in the form of an array of cards from that deck and then returns the hand. Proper version of the GenerateNewHand found in the Deck class
        static Card[] GenerateNewHand(Deck deck)
        {
            Card[] hand = new Card[Card.HAND_SIZE];
            for(int i = 0; i < Card.HAND_SIZE; i++)
            {
                hand[i] = deck.GetCard(i);
            }
            return hand;
        }


        /// <summary>
        /// Method receives a testing hand, deck, bankroll, and bet. Is a stripped-back version of the NewRound() since it does not process any card switching or deck interaction. Returns void.
        /// </summary>
        /// <param name="testingHand"></param>
        /// <param name="testingDeck"></param>
        /// <param name="testingBankrollAmount"></param>
        /// <param name="testingBetAmount"></param>
        //Method receives a testing hand, deck, bankroll, and bet. Is a stripped-back version of the NewRound() since it does not process any card switching or deck interaction. Returns void.
        static void TestingRound(Card[] testingHand, Deck testingDeck, ref int testingBankrollAmount, ref int testingBetAmount) //remember to add to bankroll
        {
            WriteLine("\n\nYour bankroll is ${0}", testingBankrollAmount);
            WriteLine("Please enter your bet");
            testingBetAmount = ValInt(BET_MIN, testingBankrollAmount, String.Format("ERROR: BET CAN ONLY BE BETWEEN {0} AND {1}", BET_MIN, testingBankrollAmount));
            testingBankrollAmount -= testingBetAmount;
            DisplayCurrentStats(testingBankrollAmount, testingBetAmount);
            DisplayCurrentHand(testingHand);
            string testResult = CheckWinningHand(testingHand);
            bool isWin = Enum.TryParse(testResult, out Payout payoutRate);
            testingBankrollAmount += (testingBetAmount * (int)payoutRate);
            PrintResult(testResult, testingBankrollAmount, testingBetAmount, isWin, payoutRate);
        }

        /// <summary>
        /// Method takes the bankroll amount and current bet amount and displays them in the console. Returns void
        /// </summary>
        /// <param name="bankrollAmount"></param>
        /// <param name="betAmount"></param>
        //Method takes the bankroll amount and current bet amount and displays them in the console. Returns void
        static void DisplayCurrentStats(int bankrollAmount, int betAmount)
        {
            WriteLine("Bankroll: ${0}", bankrollAmount);
            WriteLine("Current Bet: ${0}", betAmount);
        }

        /// <summary>
        /// Method receives the current hand and loops through each card in it, and outputs its ToString in the color of the suit. Returns void.
        /// </summary>
        /// <param name="hand"></param>
        //Method receives the current hand and loops through each card in it, and outputs its ToString in the color of the suit. Returns void.
        static void DisplayCurrentHand(Card[] hand)
        {
            WriteLine("\n\n");
            for (int i=0; i < hand.Length; i++)
            {
                if (hand[i].CardSuit == (Deck.SuitsEnumerator.Diamonds).ToString() || hand[i].CardSuit == (Deck.SuitsEnumerator.Hearts).ToString())
                    ForegroundColor = ConsoleColor.Red;

                if (hand[i].CardSuit == (Deck.SuitsEnumerator.Clubs).ToString() || hand[i].CardSuit == (Deck.SuitsEnumerator.Spades).ToString())
                    ForegroundColor = ConsoleColor.DarkGray;
                WriteLine("[{0}] {1}", i+1,hand[i]);
            }
            ResetColor();
        }

        /// <summary>
        /// Method receives the hand, deck, bankroll, and bet. Contains all of the sub-methods to switch out the user's cards, check the winning hand, update bankroll, and print the result. Returns void.
        /// </summary>
        /// <param name="hand"></param>
        /// <param name="deck"></param>
        /// <param name="bankrollAmount"></param>
        /// <param name="betAmount"></param>
        //Method receives the hand, deck, bankroll, and bet. Contains all of the sub-methods to switch out the user's cards, check the winning hand, update bankroll, and print the result. Returns void.
        static void ProcessResult(Card[] hand, Deck deck, ref int bankrollAmount, ref int betAmount)
        {
            ProcessHand(hand, deck, bankrollAmount, betAmount);
            string result = CheckWinningHand(hand);
            bool isWin = Enum.TryParse(result, out Payout payoutRate);
            bankrollAmount += (betAmount * (int)payoutRate);
            PrintResult(result, bankrollAmount, betAmount, isWin, payoutRate);
        }

        /// <summary>
        /// Method receives the result, bankroll, bet, win/loss true or false, and the payout rate of the hand, and outputs it to the console. Returns void.
        /// </summary>
        /// <param name="resultToPrint"></param>
        /// <param name="bankrollAmount"></param>
        /// <param name="betAmount"></param>
        /// <param name="isWin"></param>
        /// <param name="payoutRate"></param>
        //Method receives the result, bankroll, bet, win/loss true or false, and the payout rate of the hand, and outputs it to the console. Returns void.
        static void PrintResult(string resultToPrint, int bankrollAmount, int betAmount, bool isWin, Payout payoutRate)
        {
            WriteLine("\nResult: {0}", resultToPrint);
            if (isWin)
            {
                WriteLine("\nPayout rate: {0}", (int)payoutRate);
                WriteLine("\nWinnings from this round: ${0}", (betAmount * (int)payoutRate));
            }
            WriteLine("\nYou now have ${0}", bankrollAmount);
            ResetColor();
        }

        /// <summary>
        /// Method receives the hand, deck, bankroll, and bet. Contains the necessary sub-methods to switch, replace, and check winning hand. Returns a string based on the outcome.
        /// </summary>
        /// <param name="hand"></param>
        /// <param name="deck"></param>
        /// <param name="bankrollAmount"></param>
        /// <param name="betAmount"></param>
        /// <returns></returns>
        //Method receives the hand, deck, bankroll, and bet. Contains the necessary sub-methods to switch, replace, and check winning hand. Returns a string based on the outcome
        static string ProcessHand(Card[] hand, Deck deck, int bankrollAmount, int betAmount)
        {
            bool[] cardsToSwitch = GetCardsToSwitch(hand);
            Clear();
            DisplayCurrentStats(bankrollAmount, betAmount);
            if (cardsToSwitch.Contains(true)) //optimization, checks to see if there is even anything to switch before calling the switch functions
            {
                ReplaceSelectedCards(hand, cardsToSwitch, deck);
            }
            DisplayCurrentHand(hand);

            return CheckWinningHand(hand);
        }

        /// <summary>
        /// Method displays the round end screen and asks the user if they wish to play another round. Returns true/false based on the user's choice [Y/N]
        /// </summary>
        /// <returns></returns>
        //Method displays the round end screen and asks the user if they wish to play another round. Returns true/false based on the user's choice [Y/N]
        static bool RoundEndScreen(int bankrollAmount)
        {
            ForegroundColor = ConsoleColor.Cyan;
            WriteLine("Would you like to play another round? [Y/N]");
            bool confirm = ConfirmKeyPress();

            if (!confirm)
            {
                WriteLine("You finished with ${0}", bankrollAmount);
                WriteLine("Press any key to return to main menu");
                ReadKey();
                Clear();
            }

            return confirm;
        }

        /// <summary>
        /// Takes bankroll in the form of an int. Triggered once the player's bankroll hits zero and promptly lets the user know they wasted all of their money. Asks the user if they would like to exit and returns a true/false based on the user's choice [Y/N]
        /// </summary>
        /// <returns></returns>
        //Takes bankroll in the form of an int. Triggered once the player's bankroll hits zero and promptly lets the user know they wasted all of their money. Asks the user if they would like to exit and returns a true/false based on the user's choice [Y/N]
        static bool GameOverScreen()
        {
            WriteLine("\n\nCONGRATS DUDE YOU'RE BROKE NOW");
            WriteLine("Quit to Desktop? [Y/N]");
            bool confirm = ConfirmKeyPress();
            if (!confirm)
                Clear();

            return confirm;
        }

        /// <summary>
        /// Takes no arguments. Called when user is asked to confirm [Y/N]. Returns true/false based on the key press
        /// </summary>
        /// <returns></returns>
        //Takes no arguments. Called when user is asked to confirm [Y/N]. Returns true/false based on the key press
        static bool ConfirmKeyPress()
        {
            ConsoleKey userKeyPress = ConsoleKey.NoName;
            while (userKeyPress != ConsoleKey.Y && userKeyPress != ConsoleKey.N)
                userKeyPress = ReadKey(true).Key;

            if (userKeyPress == ConsoleKey.Y)
                return true;

            return false;
        }
        #endregion

        #region//CARD SWITCHING METHODS
        /// <summary>
        /// Receives the current hand. Asks the user which cards they would like to switch and returns a boolean array based on which ones the user wishes to swap and keep
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Asks the user which cards they would like to switch and returns a boolean array based on which ones the user wishes to swap and keep
        static bool[] GetCardsToSwitch(Card[] hand)
        {
            int loopRuns = 0;
            bool confirm = false;
            bool[] cardsToSwitch = new bool[hand.Length];


            int input = -1;
            do
            {
                for (int i = 0; i < hand.Length; i++)
                    cardsToSwitch[i] = false;
                do
                {
                    if (loopRuns == CARD_REPLACE_MAX)
                        break;

                    WriteLine("\nEnter which card you would like to replace (Max {0}), or type 0 to continue", CARD_REPLACE_MAX);
                    input = ValInt(0, hand.Length, String.Format("Please enter only a number between {0} and {1}", 0, hand.Length));


                    if (input != 0)
                    {
                        if (cardsToSwitch[input - 1])
                        {
                            ForegroundColor = ConsoleColor.Red;
                            WriteLine("Error: Card already selected");
                            ResetColor();
                            loopRuns--;
                        }
                        else
                        {
                            ForegroundColor = ConsoleColor.Green;
                            WriteLine("Card selected successfully");
                            ResetColor();
                        }
                        cardsToSwitch[input - 1] = true;
                    }


                    loopRuns++;
                } while (input != 0);
                confirm = ConfirmSwitch(cardsToSwitch);
                loopRuns = 0;
            } while (!confirm);//end of confirm loop
            return cardsToSwitch;
        }

        /// <summary>
        /// Receives/Outputs the list of cards that the user wishes to switch and then asks them to confirm their choice. Returns true or false based on it.
        /// </summary>
        /// <param name="cardsToSwitch"></param>
        /// <returns></returns>
        //Outputs the list of cards that the user wishes to switch and then asks them to confirm their choice. Returns true or false based on it.
        static bool ConfirmSwitch(bool[] cardsToSwitch)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < cardsToSwitch.Length; i++)
            {
                if (cardsToSwitch[i])
                {
                    sb.Append(i + 1);
                    sb.Append(",");
                }
            }

            ForegroundColor = ConsoleColor.Cyan;
            if (cardsToSwitch.Contains(true))
            {
                WriteLine("Cards {0} will be replaced. Confirm? [Y/N]", sb);
            }
            else
            {
                WriteLine("No cards will be replaced. Confirm? [Y/N]");
            }
            ResetColor();

            return ConfirmKeyPress();
        }

        /// <summary>
        /// Receives the current hand, the bool list of cards to replace, and the deck. Replaces the cards marked "true" with new cards pulled directly from the deck. Returns void
        /// </summary>
        /// <param name="hand"></param>
        /// <param name="cardsToSwitch"></param>
        /// <param name="deck"></param>
        //Receives the current hand, the bool list of cards to replace, and the deck. Replaces the cards marked "true" with new cards pulled directly from the deck. Returns void.
        static void ReplaceSelectedCards(Card[] hand, bool[] cardsToSwitch, Deck deck)
        {
            int switchIndex = hand.Length;
            for (int i = 0; i < hand.Length; i++)
            {
                if (cardsToSwitch[i])
                {
                    hand[i] = deck.GetCard(switchIndex);
                    switchIndex++;
                }
            }
        }
        #endregion

        #region//MAIN HAND DETECTION METHODS
        /// <summary>
        /// Receives the current hand, checks which hand type it is (including losing hand) and returns a string based on the outcome of the hand
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand, checks which hand type it is (including losing hand) and returns a string based on the outcome of the hand
        static string CheckWinningHand(Card[] hand)
        {
            ForegroundColor = ConsoleColor.Green;

            if (FullHouse(hand))
                return Payout.FullHouse.ToString();

            if (TwoPair(hand))
                return Payout.TwoPair.ToString();

            if (Pair(hand))
                return Payout.Pair.ToString();

            if (ThreeOfAKind(hand))
                return Payout.ThreeOfAKind.ToString();
            
            if (Straight(hand))
                return Payout.Straight.ToString();
            
            if (Flush(hand))
                return Payout.Flush.ToString();
            
            if (FourOfAKind(hand))
                return Payout.FourOfAKind.ToString();
            
            if (StraightFlush(hand))
                return Payout.StraightFlush.ToString();

            if (RoyalFlush(hand))
                return Payout.RoyalFlush.ToString();

            ForegroundColor = ConsoleColor.Red;
            return "No winning hand detected";
        }

        /// <summary>
        /// Receives the current hand. Checks to see if the hand is a Pair and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the hand is a Pair and returns true or false based on the outcome
        static bool Pair(Card[] hand)
        {
            bool[] highCards = new bool[hand.Length];
            int numberOfHighCards = 0;
            int innerIndex = 0;

            for (int i = 0; i < hand.Length; i++) //checks to see if the cards are high enough to warrant a pair
            {
                if (hand[i].CardNumber >= (int)Deck.FaceEnumerator.Jack || hand[i].CardNumber == 1)
                {
                    highCards[i] = true;
                    numberOfHighCards++;
                }
            }

            if (!highCards.Contains(true))
                return false;//if there are no cards that are jack or better, return false

            int[] possiblePairValues = new int[numberOfHighCards];
            for (int i = 0; i < hand.Length; i++)
            {
                if (highCards[i])
                {
                    possiblePairValues[innerIndex] = hand[i].CardNumber;
                    innerIndex++;
                }
            }

            if (possiblePairValues.Length <= 1)
                return false; //if possible pair value count is less than 1, return false as no pair can exist

            //now that all the cards in the array are jack or higher

            int[] individualValues = new int[possiblePairValues.Length];
            int[] individualValueFrequencies = new int[possiblePairValues.Length];
            int individualValueCounter = 0;
            int numberOfPairs = 0;

            for (int i = 0; i < possiblePairValues.Length; i++) //Creates an array of INDIVIDUAL values so that their frequencies can be counted
            {
                if (!individualValues.Contains(possiblePairValues[i]))
                {
                    individualValues[individualValueCounter] = possiblePairValues[i];
                    individualValueCounter++;
                }
            }

            for (int start=0; start < individualValues.Length; start++) //Counts their frequencies
            {
                for (int check=0; check < individualValues.Length;check++)
                {
                    if (individualValues[start] == possiblePairValues[check])
                    {
                        individualValueFrequencies[start]++;
                    }
                }
            }

            for (int i=0; i< individualValues.Length; i++) //Counts the number of pairs based on the frequencies
            {
                if (individualValueFrequencies[i] == AMOUNT_IN_PAIR)
                    numberOfPairs++;

                if (individualValueFrequencies[i] == AMOUNT_IN_THREE_OF_A_KIND)
                    return false;
            }

            if (numberOfPairs == 1) //Ensures that it is not mistakenly reading two pairs as only one and returning true instead of false
                return true;

            return false;
        }

        /// <summary>
        /// Receives the current hand. Checks to see if the hand is Two pair and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the hand is Two pair and returns true or false based on the outcome
        static bool TwoPair(Card[] hand)
        {
            int[] individualValues = new int[hand.Length];
            int[] individualValueFrequencies = new int[hand.Length];
            int individualValueCounter = 0;
            int numberOfPairs = 0;

            for (int i = 0; i < hand.Length; i++) //Creates an array of INDIVIDUAL values so that their frequencies can be counted
            {
                if (!individualValues.Contains(hand[i].CardNumber))
                {
                    individualValues[individualValueCounter] = hand[i].CardNumber;
                    individualValueCounter++;
                }
            }

            for (int start = 0; start < individualValues.Length; start++)
            {
                for (int check = 0; check < individualValues.Length; check++)
                {
                    if (individualValues[start] == hand[check].CardNumber)
                    {
                        individualValueFrequencies[start]++;
                    }
                }
            }

            for (int i = 0; i < individualValues.Length; i++)
            {
                if (individualValueFrequencies[i] == AMOUNT_IN_PAIR)
                    numberOfPairs++;
            }

            if (numberOfPairs == AMOUNT_OF_PAIRS_IN_2PAIR)
                return true;

            return false;
        }//end of method

        /// <summary>
        /// Receives the current hand. Checks to see if the hand is three of a kind and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the hand is three of a kind and returns true or false based on the outcome
        static bool ThreeOfAKind(Card[] hand)
        {
            int[] individualValues = new int[hand.Length];
            int[] individualValueFrequencies = new int[hand.Length];
            int individualValueCounter = 0;

            for (int i = 0; i < hand.Length; i++) //Creates an array of INDIVIDUAL values so that their frequencies can be counted
            {
                if (!individualValues.Contains(hand[i].CardNumber))
                {
                    individualValues[individualValueCounter] = hand[i].CardNumber;
                    individualValueCounter++;
                }
            }

            for (int start = 0; start < individualValues.Length; start++)
            {
                for (int check = 0; check < individualValues.Length; check++)
                {
                    if (individualValues[start] == hand[check].CardNumber)
                    {
                        individualValueFrequencies[start]++;
                    }
                }
            }

            if ((individualValueFrequencies[0] == AMOUNT_IN_PAIR && individualValueFrequencies[1] == AMOUNT_IN_THREE_OF_A_KIND) || (individualValueFrequencies[1] == AMOUNT_IN_PAIR && individualValueFrequencies[0] == AMOUNT_IN_THREE_OF_A_KIND))
                return false;

            for (int i = 0; i < individualValues.Length; i++)
            {
                if (individualValueFrequencies[i] == AMOUNT_IN_THREE_OF_A_KIND)
                    return true;
            }


            return false;
        }

        /// <summary>
        /// Receives the current hand. Checks to see if the hand is a straight and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the hand is a straight and returns true or false based on the outcome
        static bool Straight(Card[] hand)
        {
            return (CheckIfSequence(hand) && !CheckIfSameSuit(hand));
        }

        /// <summary>
        /// Receives the current hand. Checks to see if the hand is a flush and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the hand is a flush and returns true or false based on the outcome
        static bool Flush(Card[] hand)
        {
            return (CheckIfSameSuit(hand) && !CheckIfSequence(hand));
        }

        /// <summary>
        /// Receives the current hand. Checks to see if the hand is a full house and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the hand is a full house and returns true or false based on the outcome
        static bool FullHouse(Card[] hand)
        {
            int[] individualValues = new int[hand.Length];
            int[] individualValueFrequencies = new int[hand.Length];
            int individualValueCounter = 0;

            for (int i = 0; i < hand.Length; i++) //Creates an array of INDIVIDUAL values so that their frequencies can be counted
            {
                if (!individualValues.Contains(hand[i].CardNumber))
                {
                    individualValues[individualValueCounter] = hand[i].CardNumber;
                    individualValueCounter++;
                }
            }

            if (individualValueCounter != AMOUNT_IN_PAIR)
                return false;

            
            for (int start = 0; start < individualValues.Length; start++) //Counts the frequencies
            {
                for (int check = 0; check < individualValues.Length; check++)
                {
                    if (individualValues[start] == hand[check].CardNumber)
                    {
                        individualValueFrequencies[start]++;
                    }
                }
            }

            if ((individualValueFrequencies[0] == AMOUNT_IN_PAIR && individualValueFrequencies[1] == AMOUNT_IN_THREE_OF_A_KIND) || (individualValueFrequencies[1] == AMOUNT_IN_PAIR && individualValueFrequencies[0] == AMOUNT_IN_THREE_OF_A_KIND))
                return true;

            return false;
        }

        /// <summary>
        /// Receives the current hand. Checks to see if the hand is four of a kind and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the hand is four of a kind and returns true or false based on the outcome
        static bool FourOfAKind(Card[] hand)
        {
            int frequencyCounter = 0;
            for (int i = 0; i <= 1; i++)
            {
                for (int j = 0; j < hand.Length; j++)
                {
                    if (hand[j].CardNumber == hand[i].CardNumber)
                        frequencyCounter++;
                }//end of inner for loop
                if (frequencyCounter == AMOUNT_IN_FOUR_OF_A_KIND)
                    return true;

                frequencyCounter = 0;
            }//end of outer for loop
            return false;
        }//end of method

        /// <summary>
        /// Receives the current hand. Checks to see if the hand is a straight flush and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the hand is a straight flush and returns true or false based on the outcome
        static bool StraightFlush(Card[] hand)
        {
            return (CheckIfSequence(hand) && CheckIfSameSuit(hand) && !CheckIfRoyal(hand));
        }

        /// <summary>
        /// Receives the current hand. Checks to see if the hand is a royal flush and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the hand is a royal flush and returns true or false based on the outcome
        static bool RoyalFlush(Card[] hand)
        {
            return (CheckIfSequence(hand) && CheckIfSameSuit(hand) && CheckIfRoyal(hand));
        }
        #endregion

        #region//SUPPORTING HAND DETECTION METHODS
        /// <summary>
        /// Receives the current hand. Checks to see if the current hand is a sequence or not (ex: 2,3,4,5,6) and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the current hand is a sequence or not (ex: 2,3,4,5,6) and returns true or false based on the outcome
        static bool CheckIfSequence(Card[] hand)
        {
            int[] cardNumbers = new int[hand.Length];
            for (int i = 0; i < hand.Length; i++)
            {
                cardNumbers[i] = hand[i].CardNumber;
            }

            if (cardNumbers.Contains(Deck.CARDS_PER_SUIT) && cardNumbers.Contains(1)) //Ace is by default 1 (low). This checks if it is being used as high, and changes its value in the array before checking
            {
                for (int i = 0; i < cardNumbers.Length; i++)
                {
                    if (cardNumbers[i] == 1)
                        cardNumbers[i] = ACE_HIGH_VALUE;
                }
            }

            SortArray(cardNumbers);

            int validStraightCounter = 0;
            for (int i = 1; i < cardNumbers.Length; i++)
            {
                if (cardNumbers[i - 1] == cardNumbers[i] - 1)
                    validStraightCounter++;
            }

            if (validStraightCounter == cardNumbers.Length - 1)
                return true;

            return false;
        }

        /// <summary>
        /// Receives the current hand. Checks to see if all of the cards are the same suit (eg: all the cards are Clubs) and returns true or false based on the outcome
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if all of the cards are the same suit (eg: all the cards are Clubs) and returns true or false based on the outcome
        static bool CheckIfSameSuit(Card[] hand)
        {
            for (int i = 1; i < hand.Length; i++)
            {
                if (hand[i].CardSuit != hand[0].CardSuit)
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Receives the current hand. Checks to see if the cards in the hand are 10, jack, queen, king, and ace. Returns true or false based on the outcome [DOES NOT CHECK SUIT. SEE CheckIfSameSuit METHOD]
        /// </summary>
        /// <param name="hand"></param>
        /// <returns></returns>
        //Receives the current hand. Checks to see if the cards in the hand are 10, jack, queen, king, and ace. Returns true or false based on the outcome [DOES NOT CHECK SUIT. SEE CheckIfSameSuit METHOD]
        static bool CheckIfRoyal(Card[] hand)
        {
            int[] cardNumbers = new int[hand.Length];
            for (int i = 0; i < cardNumbers.Length; i++)
            {
                cardNumbers[i] = hand[i].CardNumber;
            }

            if (cardNumbers.Contains(1) && cardNumbers.Contains(ROYAL_MIN) && cardNumbers.Contains((int)Deck.FaceEnumerator.Jack) && cardNumbers.Contains((int)Deck.FaceEnumerator.Queen) && cardNumbers.Contains((int)Deck.FaceEnumerator.King))
                return true;

            return false;
        }

        /// <summary>
        /// Receives an int array and sorts it in increasing order (bubble swap algorithm). Returns void.
        /// </summary>
        /// <param name="arrayToSort"></param>
        //Receives an int array and sorts it in increasing order (bubble swap algorithm). Returns void.
        static void SortArray(int[] arrayToSort)
        {
            for (int write = 0; write < arrayToSort.Length; write++)
                for (int sort = 0; sort < arrayToSort.Length - 1; sort++)
                    if (arrayToSort[sort] > arrayToSort[sort + 1])
                        Swap(arrayToSort, sort, sort + 1);
        }

        /// <summary>
        /// Used to swap two indexes of a given int array (See SortArray method). Returns void.
        /// </summary>
        /// <param name="arrayToSort"></param>
        /// <param name="index1"></param>
        /// <param name="index2"></param>
        //Used to swap two indexes of a given int array (See SortArray method) Returns void.
        static void Swap(int[] arrayToSort, int index1, int index2)
        {
            int temp = arrayToSort[index1];
            arrayToSort[index1] = arrayToSort[index2];
            arrayToSort[index2] = temp;
        }
        #endregion

        /// <summary>
        /// Receives min value, max value, and error message and uses them to validate an integer input and output an error message if it is outside the range. Returns the valid input. [TAKEN FROM MY PERSONAL LIBRARY]
        /// </summary>
        /// <param name="minValue"></param>
        /// <param name="maxValue"></param>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        //Receives min value, max value, and error message and uses them to validate an integer input and output an error message if it is outside the range. Returns the valid input. [TAKEN FROM MY PERSONAL LIBRARY]
        static int ValInt(int minValue, int maxValue, string errorMessage)
        {
            bool isInt;
            int userNumPress;
            do
            {
                isInt = int.TryParse(Console.ReadLine(), out userNumPress);
                if (!isInt | userNumPress < minValue | userNumPress > maxValue)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("{0}", errorMessage);
                    Console.ResetColor();
                }
            } while (!isInt | userNumPress < minValue | userNumPress > maxValue);
            return userNumPress;
        }//end of function

        /// <summary>
        /// Stores the payout rates for each hand in an enumerator
        /// </summary>
        //Stores the payout rates for each hand in an enumerator
        public enum Payout
        {
            Pair = 1,
            TwoPair = 2,
            ThreeOfAKind = 3,
            Straight = 4,
            Flush = 6,
            FullHouse = 9,
            FourOfAKind = 25,
            StraightFlush = 50,
            RoyalFlush = 250
        }
    }//end of class
    /* what a card could possibly look like in the future graphically
----------------------
| 5                  |
|                    |
|                    |
|                    |
|                    |
|        <3          |
|                    |
|                    |
|                    |
|                    |
|                    |
|                   5|
----------------------*/
}//end of namespace

