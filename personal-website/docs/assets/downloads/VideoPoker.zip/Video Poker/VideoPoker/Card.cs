﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoPoker
{
    /// <summary>
    /// Represents a playing card with a suit, number, and face. Possesses deck position value for when used in a full deck
    /// </summary>
    //Represents a playing card with a suit, number, and face. Possesses deck position value for when used in a full deck
    class Card
    {
        public const int HAND_SIZE = 5;
        private int _cardNumber;
        private int _deckPosition;
        private string _cardFace;
        private string _cardSuit;
        private bool _used;

        /// <summary>
        /// Default constructor initializes the card's number to zero, its face to null, and its Used status to false
        /// </summary>
        //Default constructor initializes the card's number to zero, its face to null, and its Used status to false
        public Card()
        {
            CardNumber = 0;
            CardFace = null;
            Used = false; //If the card was used in the deck or not. Included for future expandibility
        }

        /// <summary>
        /// Gets/Sets the card's number. Throws exception if number is negative or higher than a king (Ace is low(1) by default)
        /// </summary>
        //Gets/Sets the card's number. Throws exception if number is negative or higher than a king (Ace is low(1) by default)
        public int CardNumber
        {
            get
            {
                return _cardNumber;
            }
            set
            {
                if (value > Deck.CARDS_PER_SUIT)
                    throw new ArgumentOutOfRangeException("_cardNumber", String.Format("ERROR: CARD NUMBER CANNOT BE HIGHER THAN {0}", Deck.CARDS_PER_SUIT));

                if (value < 0)
                    throw new ArgumentOutOfRangeException("_cardNumber", String.Format("ERROR: CARD NUMBER CANNOT BE NEGATIVE"));

                _cardNumber = value;
            }
        }

        /// <summary>
        /// Gets/Sets the card's position within the deck in integer form. Throws exception if position is negative or greater than the deck's size itself
        /// </summary>
        //Gets/Sets the card's position within the deck in integer form. Throws exception if position is negative or greater than the deck's size itself
        public int DeckPosition
        {
            get
            {
                return _deckPosition;
            }
            set
            {
                if (value > Deck.SIZE)
                    throw new ArgumentOutOfRangeException("_deckPosition",String.Format("ERROR: DECK POSITION CANNOT BE HIGHER THAN THE NUMBER OF CARDS IN THE DECK ({0})", Deck.SIZE));

                if (value < 0)
                    throw new ArgumentOutOfRangeException("_deckPosition","ERROR: DECK POSITION CANNOT BE NEGATIVE");

                _deckPosition = value;
            }
        }

        /// <summary>
        /// Gets/Sets the card's face as a string (ex: King)
        /// </summary>
        //Gets/Sets the card's face as a string (ex: King)
        public string CardFace
        {
            get
            {
                return _cardFace;
            }
            set
            {
                _cardFace = value;
            }
        }

        /// <summary>
        /// Gets/Sets the card's suit as a string (ex: Spades)
        /// </summary>
        //Gets/Sets the card's suit as a string (ex: Spades)
        public string CardSuit
        {
            get
            {
                return _cardSuit;
            }
            set
            {
                _cardSuit = value; 
            }
        }

        /// <summary>
        /// Gets/Sets the card's used status as a Boolean (if card was used in the deck already -> used == true)
        /// </summary>
        //Gets/Sets the card's used status as a Boolean (if card was used in the deck already -> used == true)
        public bool Used
        {
            get
            {
                return _used;
            }
            set
            {
                _used = value;
            }
        }

        /// <summary>
        /// ToString override checks to see if the card is an ace or not, returns a string with the card's number, face if applicable, and suit
        /// </summary>
        /// <returns></returns>
        //ToString override checks to see if the card is an ace or not, returns a string with the card's number, face if applicable, and suit
        public override string ToString()
        {
            if (CardNumber == 1)
            {
                return String.Format("Ace of {0}", CardSuit);
            }
            else if (CardFace != null)
            {
                return String.Format("{0} of {1}", CardFace, CardSuit);
            }
            else
                return String.Format("{0} of {1}", CardNumber, CardSuit);

        }

    }//end of class
}//end of namespace
