﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MatteWebApplication.Migrations
{
    public partial class reviews : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_SaleTimerModel",
                table: "SaleTimerModel");

            migrationBuilder.RenameTable(
                name: "SaleTimerModel",
                newName: "SaleTimers");

            migrationBuilder.AddPrimaryKey(
                name: "PK_SaleTimers",
                table: "SaleTimers",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "Reviews",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    Author = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NumberOfStars = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reviews", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Reviews");

            migrationBuilder.DropPrimaryKey(
                name: "PK_SaleTimers",
                table: "SaleTimers");

            migrationBuilder.RenameTable(
                name: "SaleTimers",
                newName: "SaleTimerModel");

            migrationBuilder.AddPrimaryKey(
                name: "PK_SaleTimerModel",
                table: "SaleTimerModel",
                column: "Id");
        }
    }
}
