﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MatteWebApplication.Migrations
{
    public partial class testemptydescriptionfield : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
