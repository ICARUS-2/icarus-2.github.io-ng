﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MatteWebApplication.Migrations
{
    public partial class multiplecurrencies : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SalePrice",
                table: "Products",
                newName: "UsdSalePrice");

            migrationBuilder.RenameColumn(
                name: "Price",
                table: "Products",
                newName: "UsdPrice");

            migrationBuilder.AddColumn<double>(
                name: "AudPrice",
                table: "Products",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "AudSalePrice",
                table: "Products",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "CadPrice",
                table: "Products",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "CadSalePrice",
                table: "Products",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "EurPrice",
                table: "Products",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "EurSalePrice",
                table: "Products",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "GbpPrice",
                table: "Products",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "GbpSalePrice",
                table: "Products",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AudPrice",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "AudSalePrice",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "CadPrice",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "CadSalePrice",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "EurPrice",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "EurSalePrice",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "GbpPrice",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "GbpSalePrice",
                table: "Products");

            migrationBuilder.RenameColumn(
                name: "UsdSalePrice",
                table: "Products",
                newName: "SalePrice");

            migrationBuilder.RenameColumn(
                name: "UsdPrice",
                table: "Products",
                newName: "Price");
        }
    }
}
