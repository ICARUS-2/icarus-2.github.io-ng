﻿namespace MatteWebApplication.Helpers
{
    /// <summary>
    /// A static set of constants used for marking TempData and ViewData keys.
    /// </summary>
    public class TempDataHelper
    {
        /// <summary>
        /// Used for when an operation has succeeded.
        /// </summary>
        public const string SUCCESS_DATA = "SuccessData";

        /// <summary>
        /// Used to warn a user about something important.
        /// </summary>
        public const string WARNING_DATA = "WarningData";

        /// <summary>
        /// Used when an operation has failed.
        /// </summary>
        public const string FAILURE_DATA = "FailureData";
    }
}
