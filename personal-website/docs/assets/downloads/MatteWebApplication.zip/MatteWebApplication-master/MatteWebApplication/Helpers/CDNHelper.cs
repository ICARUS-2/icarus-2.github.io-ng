﻿using MatteWebApplication.Models.Store;

namespace MatteWebApplication.Helpers
{
    /// <summary>
    /// Class containing static methods for interactions with files stored in the wwwroot directory.
    /// </summary>
    public class CDNHelper
    {
        /// <summary>
        /// Gets base path for stored StoreImage objects from the wwwroot directory.
        /// </summary>
        public static string GetImageBasePath
        { 
            get
            {
                return "\\store-images\\product";
            }
        }

        /// <summary>
        /// Gets the prefix for image deletion markers on a product edit form.
        /// </summary>
        public static string DeleteImagePrefix
        {
            get
            {
                return "deleteImage_";
            }
        }

        /// <summary>
        /// Constructs path to a product image from the image base path.
        /// </summary>
        /// <param name="productId">The ID of the product whose image data will be stored in the file structure.</param>
        /// <returns>The directory path from wwwroot that will store the image data for that product.</returns>
        public static string ConstructPathToStoreImage(int productId)
        {
            return string.Format("{0}\\{1}", GetImageBasePath, productId);
        }

        /// <summary>
        /// Uploads an image file to the wwwroot directory.
        /// </summary>
        /// <param name="file">The image file to be uploaded and saved.</param>
        /// <param name="productId">The product's ID.</param>
        /// <param name="rootPath">The wwwroot path.</param>
        /// <returns>The absolute path to the image.</returns>
        public static async Task<string> UploadImageAsync(IFormFile file, int productId, string rootPath)
        {
            string imageDirectoryPath = rootPath + ConstructPathToStoreImage(productId);

            //Get full path to image
            string fullImagePath = imageDirectoryPath + "\\" + file.FileName;

            //Create directory
            if (!Directory.Exists(imageDirectoryPath))
            {
                Directory.CreateDirectory(imageDirectoryPath);
            }

            //Remove existing image to overwrite if necessary
            DeleteImage(fullImagePath);

            //Write the file to the directory
            using (FileStream stream = System.IO.File.Create(fullImagePath))
            {
                await file.CopyToAsync(stream);
            }

            return fullImagePath;
        }

        /// <summary>
        /// Takes in an image's path and deletes it.
        /// </summary>
        /// <param name="path">The full path to the image.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public static bool DeleteImage(string path)
        {
            try
            {
                if (System.IO.File.Exists(path))
                {
                    System.IO.File.Delete(path);
                }
            }
            catch(Exception ex)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Deletes all images for a given product's ID.
        /// </summary>
        /// <param name="rootPath">The wwwroot path.</param>
        /// <param name="productId">The ID of the product whose data will be removed.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public static bool DeleteAllProductImages(string rootPath, int productId)
        {
            string imageDirectoryPath = rootPath + ConstructPathToStoreImage(productId);

            try
            {
                if (Directory.Exists(imageDirectoryPath))
                {
                    Directory.Delete(imageDirectoryPath, true);
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Converts an image's absolute path to a path that can be read and interpreted by the browser.
        /// </summary>
        /// <param name="path">The full path to the image.</param>
        /// <returns>The relative path that can be used in a browser window.</returns>
        public static string ConvertFullPathToBrowserSource(string path)
        {
            if (path == null || !path.Contains("wwwroot"))
            {
                GetNotFoundImgPath();
            }

            string[] splitPath = path.Split("wwwroot");
            string relativePath = splitPath[1];
            relativePath = relativePath.Replace("\\", "/");

            return relativePath;
        }
        
        /// <summary>
        /// Retrieves the relative path to the default "not found" image.
        /// </summary>
        /// <returns>The relative path to the not found image.</returns>
        public static string GetNotFoundImgPath()
        {
            return "/assets/not-found.png";
        }

        /// <summary>
        /// Generates an HTML ID for a checkbox that will be used to mark an image for deletion.
        /// </summary>
        /// <param name="imgId">The ID of the store image.</param>
        /// <returns>The ID for the checkbox.</returns>
        public static string GenerateImageDeletionCheckboxId(int imgId)
        {
            return DeleteImagePrefix + imgId;
        }
    }
}
