﻿using MatteWebApplication.Models.Store;

namespace MatteWebApplication.Helpers
{
    public class RegionHelper
    {
        public static string COOKIE_KEY = "matteWeb_Region";
        public const Region DEFAULT_REGION = Region.CA; 

        public enum Region
        {
            CA,
            US,
            UK,
            EU,
            AU
        }

        public static Region ParseString(string str)
        {
            try
            {
                return (RegionHelper.Region)Enum.Parse(typeof(RegionHelper.Region), str.ToString().ToUpper());
            }
            catch (Exception ex)
            {
                return DEFAULT_REGION;
            }
        }
        public static string RegionDollarToCurrencyTicker(Region region)
        {
            switch(region)
            {
                case Region.CA:
                    return "CAD";
                case Region.US:
                    return "USD";
                case Region.AU:
                    return "AUD";
                default:
                    return "";
            }
        }

        public static string GetRegionCurrencySymbol(Region region)
        {
            switch(region)
            {
                case Region.CA:
                    return "$";
                case Region.US:
                    return "$";
                case Region.AU:
                    return "$";
                case Region.UK:
                    return "£";
                case Region.EU:
                    return "€";
                default:
                    return "";
            }
        }

        public static PriceDisplayModel GetProductDisplayPrice(Product product, Region region)
        {
            switch(region)
            {
                case Region.CA:
                    return new PriceDisplayModel() { Price = product.CadPrice, SalePrice = product.CadSalePrice };
                case Region.US:
                    return new PriceDisplayModel() { Price = product.UsdPrice, SalePrice = product.UsdSalePrice };
                case Region.AU:
                    return new PriceDisplayModel() { Price = product.AudPrice, SalePrice = product.AudSalePrice };
                case Region.UK:
                    return new PriceDisplayModel() { Price = product.GbpPrice, SalePrice = product.GbpSalePrice };
                case Region.EU:
                    return new PriceDisplayModel() { Price = product.EurPrice, SalePrice = product.EurSalePrice };
                default:
                    return new PriceDisplayModel() { Price = 0, SalePrice = 0 };
            }
        }
    }
}