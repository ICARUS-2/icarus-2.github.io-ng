﻿namespace MatteWebApplication.Helpers
{
    /// <summary>
    /// Contains methods to help display YouTube content/
    /// </summary>
    public class YoutubeHelper
    {
        /// <summary>
        /// Takes in a YouTube embed link and returns its thumbnail source URL.
        /// </summary>
        /// <param name="link">The YouTube link for which the thumbnail will be retrieved.</param>
        /// <returns>The thumbnail link for that video.</returns>
        public static string GetThumbnailFromEmbedLink(string link)
        {
            //https://www.youtube.com/embed/gTp4sZtjHS
            //https://img.youtube.com/vi/N2R4RhSWvU8/0.jpg
            try
            {
                if (link == null)
                    return String.Empty;

                link = link.Replace("www.youtube.com", "img.youtube.com");
                link = link.Replace("/embed/", "/vi/");
                link = link + "/0.jpg";
                return link;
            }
            catch(Exception ex)
            {
                return String.Empty;
            }
        }
    }
}
