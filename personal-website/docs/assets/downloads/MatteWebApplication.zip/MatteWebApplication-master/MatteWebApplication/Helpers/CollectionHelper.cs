﻿namespace MatteWebApplication.Helpers
{
    public class CollectionHelper
    {
        public enum CollectionType
        {
            BestSellers,
            Featured,
            NewArrivals
        }

        public static readonly Dictionary<CollectionType, string> CollectionNames = new Dictionary<CollectionType, string>()
        {
            { CollectionType.BestSellers, "Best Sellers" },
            { CollectionType.Featured, "Featured" },
            { CollectionType.NewArrivals, "New Arrivals"}
        };

        public static readonly Dictionary<CollectionType, string> ActionNames = new Dictionary<CollectionType, string>()
        {
            { CollectionType.BestSellers, "best-sellers" },
            { CollectionType.Featured, "featured" },
            { CollectionType.NewArrivals, "new-arrivals"}
        };

    }
}
