﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace MatteWebApplication.Models.Store
{
    /// <summary>
    /// Stores data about a store category
    /// </summary>
    public class Category
    {
        /// <summary>
        /// The primary key in the database.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// The category name.
        /// </summary>
        [Required]
        [NotNull]
        [MinLength(1)]
        public string Name { get; set; }

        /// <summary>
        /// The products associated with the category.
        /// </summary>
        List<Product> Products { get; set; }
    }
}
