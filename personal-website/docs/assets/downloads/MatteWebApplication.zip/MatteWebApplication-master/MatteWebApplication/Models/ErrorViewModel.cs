namespace MatteWebApplication.Models
{
    /// <summary>
    /// The viewmodel representing an error.
    /// </summary>
    public class ErrorViewModel
    {
        /// <summary>
        /// The ID of the HTTP request.
        /// </summary>
        public string? RequestId { get; set; }

        /// <summary>
        /// Whether to display the request ID or not.
        /// </summary>
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}