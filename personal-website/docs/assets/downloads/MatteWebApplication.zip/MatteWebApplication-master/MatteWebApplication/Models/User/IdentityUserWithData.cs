﻿using Microsoft.AspNetCore.Identity;

namespace MatteWebApplication.Models.User
{
    /// <summary>
    /// Stores an IdentityUser and its corresponding UserData in one object.
    /// </summary>
    public class IdentityUserWithData
    {
        /// <summary>
        /// All the data not directly stored within the IdentityUser.
        /// </summary>
        public UserDataModel UserData { get; set; }

        /// <summary>
        /// The IdentityUser whose data is being stored.
        /// </summary>
        public IdentityUser User { get; set; }
    }
}
