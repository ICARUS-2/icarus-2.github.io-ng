﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace MatteWebApplication.Models.Store
{
    public class Review
    {
        [Key]
        public int Id { get; set; }

        public int ProductId { get; set; }

        [Required]
        public string Author { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        [Required]
        [DisplayName("Number of Stars")]
        [Range(0, 5)]
        public double NumberOfStars { get;set; }
    }
}
