﻿using System.ComponentModel.DataAnnotations;

namespace MatteWebApplication.Models.User
{
    /// <summary>
    /// Stores additional data about a user that is not stored in the default IdentityUser class.
    /// </summary>
    public class UserDataModel
    {
        /// <summary>
        /// The primary key of the IdentityUser.
        /// </summary>
        [Key]
        public string Id { get; set; }

        /// <summary>
        /// Represents whether the user is a site administrator or not.
        /// </summary>
        public bool IsAdmin { get; set; } = false;

        /// <summary>
        /// Represents whether the user is a webmaster or not.
        /// </summary>
        public bool IsMaster { get; set; } = false;

        /// <summary>
        /// Whether the user is subscribed to marketing/promotional emails
        /// </summary>
        public bool IsPromotionalSubscribed { get; set; } = false;
    }
}
