﻿using System.ComponentModel.DataAnnotations;

namespace MatteWebApplication.Models.Communication
{
    /// <summary>
    /// Contains the fields that will be sent in a promotional/marketing email.
    /// </summary>
    public class PromotionalEmailModel
    {
        /// <summary>
        /// The subject of the email.
        /// </summary>
        [Required]
        public string Subject { get; set; }

        /// <summary>
        /// The message body of the email.
        /// </summary>
        [Required]
        [DataType(DataType.MultilineText)]
        public string Body { get; set; }
    }
}
