﻿using System.ComponentModel.DataAnnotations;

namespace MatteWebApplication.Models.Communication
{
    /// <summary>
    /// Stores data about a contact receiver (someone who will receive all data sent through a contact form).
    /// </summary>
    public class ContactReceiverModel
    {
        /// <summary>
        /// The primary key.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// The email the data will be sent to.
        /// </summary>
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
