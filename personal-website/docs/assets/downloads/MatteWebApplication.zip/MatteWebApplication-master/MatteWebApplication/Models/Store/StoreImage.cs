﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MatteWebApplication.Models.Store
{
    /// <summary>
    /// Stores image data about a product.
    /// </summary>
    public class StoreImage
    {
        /// <summary>
        /// The primary key.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// A short image title.
        /// </summary>
        public string Title { get; set; } 

        /// <summary>
        /// The full path to the image.
        /// </summary>
        public string PathToImage { get;set; }

        /// <summary>
        /// Foreign key for the associated product.
        /// </summary>
        [ForeignKey("Product")]
        public int ProductId { get; set; }
    }
}
