﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace MatteWebApplication.Models.Store
{
    /// <summary>
    /// Stores data about a product in the store.
    /// </summary>
    public class Product
    {
        /// <summary>
        /// The primary key.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// The product's displayed name.
        /// </summary>
        [Required]
        public string Name { get; set; }

        /// <summary>
        /// A short description about the product.
        /// </summary>
        [Required]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        /// <summary>
        /// Any additional information the buyer should know.
        /// </summary>
        [DataType(DataType.MultilineText)]
        [DisplayName("Additional Info")]
        [ValidateNever]
        public string AdditionalInfo { get; set; } = string.Empty;

        /// <summary>
        /// Link to the store
        /// </summary>
        [Required]
        [DisplayName("Product Page Link")]
        public string Link { get; set; }

        /// <summary>
        /// Whether the product is on sale or not.
        /// </summary>
        [Required]
        [DisplayName("On Sale")]
        public bool IsOnSale { get; set; }

        /// <summary>
        /// The regular price of the product (CAD).
        /// </summary>
        [Required]
        [DisplayName("CAD Price")]
        [Range(0, Double.MaxValue)]
        public double CadPrice { get; set; }

        /// <summary>
        /// The sale price (CAD) of the product that will be displayed when it is on sale.
        /// </summary>
        [Required]
        [DisplayName("CAD Sale Price")]
        [Range(0, Double.MaxValue)]
        public double CadSalePrice { get; set; }

        /// <summary>
        /// The regular price of the product (CAD).
        /// </summary>
        [Required]
        [DisplayName("USD Price")]
        [Range(0, Double.MaxValue)]
        public double UsdPrice { get; set; }

        /// <summary>
        /// The sale price (USD) of the product that will be displayed when it is on sale.
        /// </summary>
        [Required]
        [DisplayName("USD Sale Price")]
        [Range(0, Double.MaxValue)]
        public double UsdSalePrice { get; set; }

        /// <summary>
        /// The regular price of the product (AUD).
        /// </summary>
        [Required]
        [DisplayName("AUD Price")]
        [Range(0, Double.MaxValue)]
        public double AudPrice { get; set; }

        /// <summary>
        /// The sale price (AUD) of the product that will be displayed when it is on sale.
        /// </summary>
        [Required]
        [DisplayName("AUD Sale Price")]
        [Range(0, Double.MaxValue)]
        public double AudSalePrice { get; set; }

        /// <summary>
        /// The regular price of the product (EUR).
        /// </summary>
        [Required]
        [DisplayName("EUR Price")]
        [Range(0, Double.MaxValue)]
        public double EurPrice { get; set; }

        /// <summary>
        /// The sale price (EUR) of the product that will be displayed when it is on sale.
        /// </summary>
        [Required]
        [DisplayName("EUR Sale Price")]
        [Range(0, Double.MaxValue)]
        public double EurSalePrice { get; set; }

        /// <summary>
        /// The regular price of the product (Gbp).
        /// </summary>
        [Required]
        [DisplayName("GBP Price")]
        [Range(0, Double.MaxValue)]
        public double GbpPrice { get; set; }

        /// <summary>
        /// The sale price (Gbp) of the product that will be displayed when it is on sale.
        /// </summary>
        [Required]
        [DisplayName("GBP Sale Price")]
        [Range(0, Double.MaxValue)]
        public double GbpSalePrice { get; set; }

        /// <summary>
        /// The category associated with the product.
        /// </summary>
        [ValidateNever]
        public Category Category { get; set; }

        /// <summary>
        /// The images for the product.
        /// </summary>
        [ValidateNever]
        [DisplayName("Store Images")]
        public List<StoreImage> StoreImages { get; set; }

        /// <summary>
        /// YouTube video links, separated by space
        /// </summary>
        [DataType(DataType.MultilineText)]
        [ValidateNever]
        [DisplayName("YouTube Video Links")]
        public string YoutubeLinks { get; set; }

        /// <summary>
        /// Is part of the best seller collection
        /// </summary>
        [Required]
        [DisplayName("Best Seller Collection")]
        public bool IsBestSeller { get; set; }

        /// <summary>
        /// Is part of the featured collection
        /// </summary>
        [Required]
        [DisplayName("Featured Collection")]
        public bool IsFeatured { get; set; }

        /// <summary>
        /// Is part of the new arrivals collection
        /// </summary>
        [Required]
        [DisplayName("New Arrival Collection")]
        public bool IsNewArrival { get; set; }

        /// <summary>
        /// Splits the YouTube links separated by space and returns them as an array.
        /// </summary>
        /// <returns>The array of YouTube links.</returns>
        public string[] GetYoutubeLinksArray() 
        {
            if (String.IsNullOrEmpty(YoutubeLinks))
                return new string[0];

            return YoutubeLinks.Split(" "); 
        }
    }
}
