﻿using System.ComponentModel.DataAnnotations;

namespace MatteWebApplication.Models.Store
{
    public class SaleTimerModel
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public DateTime Time { get; set; }
    }
}
