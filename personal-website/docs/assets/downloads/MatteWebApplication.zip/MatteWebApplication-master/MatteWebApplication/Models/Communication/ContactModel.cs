﻿using System.ComponentModel.DataAnnotations;

namespace MatteWebApplication.Models.Communication
{
    /// <summary>
    /// Stores data about a site's contact form submission.
    /// </summary>
    public class ContactModel
    {
        /// <summary>
        /// The first name of the person.
        /// </summary>
        [Required]
        public string FirstName { get; set; }

        /// <summary>
        /// The last name of the person.
        /// </summary>
        [Required]
        public string LastName { get; set; }

        /// <summary>
        /// The email address of the sender.
        /// </summary>
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        /// <summary>
        /// The message the user is sending.
        /// </summary>
        [Required]
        [DataType(DataType.MultilineText)]
        public string Message { get; set; }
    }
}
