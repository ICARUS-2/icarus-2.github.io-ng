﻿namespace MatteWebApplication.Models.Store
{
    public class PriceDisplayModel
    {
        public double Price { get; set; }
        public double SalePrice { get; set; }
    }
}
