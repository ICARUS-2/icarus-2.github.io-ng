﻿namespace MatteWebApplication.Models.Misc
{
    /// <summary>
    /// Contains information about a testimonial for the site.
    /// </summary>
    public class TestimonialModel
    {
        /// <summary>
        /// The image source for the testimonial.
        /// </summary>
        public string ImgSrc { get; set; }

        /// <summary>
        /// The main text body.
        /// </summary>
        public string TextContent { get; set; }

        /// <summary>
        /// Name of the person who wrote it.
        /// </summary>
        public string Author { get; set; }
    }
}
