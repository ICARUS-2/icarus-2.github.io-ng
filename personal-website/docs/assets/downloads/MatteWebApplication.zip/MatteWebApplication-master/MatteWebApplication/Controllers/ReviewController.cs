﻿using MatteWebApplication.Data.Repositories.AppData;
using MatteWebApplication.Data.Repositories.Auth;
using MatteWebApplication.Helpers;
using MatteWebApplication.Models.Store;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace MatteWebApplication.Controllers
{
    public class ReviewController : BaseController
    {
        private readonly IAppDataRepository _appDataRepository;

        public ReviewController(IAuthRepository authRepository, IAppDataRepository appDataRepository, UserManager<IdentityUser> userManager) 
            : base(authRepository, userManager) 
        {
            _appDataRepository = appDataRepository;
        }

        [HttpGet]
        [Route("/review/{id}/list")]
        public async Task<IActionResult> List(int id)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            Product product = await _appDataRepository.GetProductByIdAsync(id);
            
            if (product == null)
            {
                return NotFound();
            }

            List<Review> list = await _appDataRepository.GetReviewsForProductAsync(id);

            if (list == null)
            {
                return NotFound();
            }

            ViewData["productName"] = product.Name;
            ViewData["productId"] = product.Id;

            return View(list);
        }

        [HttpGet]
        [Route("/review/{id}/create")]
        public async Task<IActionResult> Create(int id)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            Product product = await _appDataRepository.GetProductByIdAsync(id);

            if (product == null)
            {
                return NotFound();
            }

            ViewData["productName"] = product.Name;

            Review review = new Review();
            review.ProductId = id;

            return View(review);
        }

        [HttpPost]
        [Route("review/{id}/create")]
        public async Task<IActionResult> Create(Review review)
        {
            review.Id = 0;
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            if (!ModelState.IsValid)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Model State Invalid";
                return RedirectToAction("create", "review", new { id = review.ProductId });
            }

            Product product = await _appDataRepository.GetProductByIdAsync(review.ProductId);

            if (product == null)
            {
                return Redirect("/");
            }

            bool success = await _appDataRepository.CreateReviewAsync(review);

            if (success)
            {
                TempData[TempDataHelper.SUCCESS_DATA] = String.Format("Successfully created review {0}", review.Title);
            }
            else
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Review not created - Database error";
            }

            return RedirectToAction("list", "review", new { id=review.ProductId });
        }

        [HttpGet]
        [Route("review/{id}/edit")]
        public async Task<IActionResult> Edit(int id)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            Review review = await _appDataRepository.GetReviewByIdAsync(id);

            if (review == null)
            {
                return NotFound();
            }

            return View(review);
        }


        [HttpPost]
        [Route("review/{id}/edit")]
        public async Task<IActionResult> Edit(Review review)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            if (!ModelState.IsValid)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Model State Invalid";
                return RedirectToAction("edit", "review", new { id = review.Id });
            }

            Review reviewToEdit = await _appDataRepository.GetReviewByIdAsync(review.Id);

            if (reviewToEdit == null)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Review not found";
                return RedirectToAction("list", "review", new { id = review.ProductId });
            }

            reviewToEdit.NumberOfStars = review.NumberOfStars;
            reviewToEdit.Author = review.Author;
            reviewToEdit.Description = review.Description;
            reviewToEdit.Title = review.Title;
            
            bool success = await _appDataRepository.UpdateReviewAsync(reviewToEdit);

            if (success) 
            {
                TempData[TempDataHelper.SUCCESS_DATA] = "Successfully edit review " + review.Title;
            }
            else
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Edit review failed - Database Error";
            }

            return RedirectToAction("list", "review", new { id = review.ProductId });
        }

        [HttpGet]
        [Route("review/{id}/delete")]
        public async Task<IActionResult> Delete(int id)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            Review review = await _appDataRepository.GetReviewByIdAsync(id);

            if (review == null)
            {
                return NotFound();
            }

            return View(review);
        }

        [HttpPost]
        [Route("review/{id}/delete")]
        public async Task<IActionResult> Delete(int id, IFormCollection form)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            Review review = await _appDataRepository.GetReviewByIdAsync(id);

            if (review == null)
            {
                return NotFound();
            }

            bool success = await _appDataRepository.DeleteReviewAsync(id);

            if (success)
            {
                TempData[TempDataHelper.SUCCESS_DATA] = "Successfully deleted review " + review.Title;
            }
            else
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Delete review failed - Database error";
            }

            return RedirectToAction("list", "review", new { id = review.ProductId });
        }
    }
}
