﻿using MatteWebApplication.Data.Repositories.AppData;
using MatteWebApplication.Data.Repositories.Auth;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MatteWebApplication.Models.User;
using MatteWebApplication.Helpers;

namespace MatteWebApplication.Controllers
{
    /// <summary>
    /// Controller for managing user settings outside of the main IdentityUser fields.
    /// </summary>
    public class OtherSettingsController : BaseController
    {
        //private readonly IAppDataRepository _appDataRepository;
        private readonly IAuthRepository _authRepository;
        //private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;

        /// <summary>
        /// Takes in injected IAppDataRepository, IAuthRepository, UserManager and SignInManager instances to create the controller.
        /// Inherits from BaseController.
        /// </summary>
        /// <param name="appDataRepository">Injected IAppDataRepository instance.</param>
        /// <param name="authRepository">Injected IAuthRepository instance.</param>
        /// <param name="userManager">Injected UserManager instance.</param>
        /// <param name="signInManager">Injected IAppDataRepository instance.</param>
        public OtherSettingsController(
            IAppDataRepository appDataRepository, 
            IAuthRepository authRepository,
            UserManager<IdentityUser> userManager,
            SignInManager<IdentityUser> signInManager) : base(authRepository, userManager)
        {
            //_appDataRepository = appDataRepository;
            _authRepository = authRepository;
            //_userManager = userManager;
            _signInManager = signInManager;
        }

        public async Task<IActionResult> Index()
        {
            string region = GetRegion();

            ViewData[RegionHelper.COOKIE_KEY] = region;

            if (_signInManager.IsSignedIn(User))
            {
                IdentityUser user = await GetCurrentUserAsync();
                UserDataModel userData = await _authRepository.GetUserDataByIdAsync(user.Id);

                if (userData == null)
                {
                    return NotFound();
                }
                return View(userData);
            }

            return View();
        }

        /// <summary>
        /// HTTP post takes a boolean value and sets the user data subscription field with its value.
        /// </summary>
        /// <param name="shouldSubscribe">True if user is subscribing and false if unsubscribing.</param>
        /// <returns>Redirect to the main other settings view.</returns>
        [HttpPost]
        public async Task<IActionResult> SetPromotionalSubscription(bool shouldSubscribe)
        {
            if (!_signInManager.IsSignedIn(User))
            {
                return View("AccessDenied");
            }

            IdentityUser user = await GetCurrentUserAsync();
            UserDataModel userData = await _authRepository.GetUserDataByIdAsync(user.Id);

            if (userData == null)
            {
                return NotFound();
            }

            bool success = await _authRepository.SetUserPromotionalSubscriptionAsync(user.Id, shouldSubscribe);

            if (success)
            {
                TempData[TempDataHelper.SUCCESS_DATA] = string.Format("Successfully {0} {1} promotional emails.", shouldSubscribe ? "subscribed" : "unsubscribed", shouldSubscribe ? "to" : "from");
            }
            else
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Operation failed - Database Error";
            }

            return RedirectToAction("Index");
        }
    }
}
