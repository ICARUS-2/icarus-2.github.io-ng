﻿using MatteWebApplication.Data.Repositories.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Linq;
using MatteWebApplication.Models.User;
using MatteWebApplication.Helpers;
using System.Diagnostics.Eventing.Reader;

namespace MatteWebApplication.Controllers
{
    /// <summary>
    /// Controller used to manage admin/user permissions and to ban/unban users.
    /// </summary>
    [Authorize]
    public class UserManagerController : BaseController
    {
        /// <summary>
        /// Takes in injected IAuthRepository and IdentityUser UserManager instances to instantiate the controller.
        /// </summary>
        /// <param name="authRepository">Injected IAuthRepository instance.</param>
        /// <param name="userManager">Injected IdentityUser UserManager instance.</param>
        public UserManagerController(IAuthRepository authRepository, UserManager<IdentityUser> userManager) : base(authRepository, userManager)
        {

        }

        /// <summary>
        /// The list view for the user management system.
        /// </summary>
        /// <returns>A view with a list of users and management controls.</returns>
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
            {
                return View("AccessDenied");
            }
            List<IdentityUserWithData> userData = await GetNonMasterUsersAndDataAsync(true);
            return View(userData);
        }

        /// <summary>
        /// Gets all the users except for webmasters.
        /// </summary>
        /// <param name="excludeSelf">Set to true to exclude the current user.</param>
        /// <returns>The list of users excluding webmasters.</returns>
        private async Task<List<IdentityUserWithData>> GetNonMasterUsersAndDataAsync(bool excludeSelf)
        {
            //The current user
            IdentityUser current = await GetCurrentUserAsync();

            //All users
            List<IdentityUser> users = await _authRepository.GetUsersAsync();

            //All users excluding master and optionally, self
            List<IdentityUserWithData> filteredUsersAndData = new List<IdentityUserWithData>();
            foreach (IdentityUser user in users) 
            {
                if (excludeSelf)
                {
                    if (current.Id == user.Id)
                        continue;
                }

                UserDataModel userData = await _authRepository.GetUserDataByIdAsync(user.Id);
                if (!userData.IsMaster)
                {
                    filteredUsersAndData.Add(new IdentityUserWithData(){ User = user, UserData = userData } );
                }
            }

            //Returns list of filtered users and their respective data
            return filteredUsersAndData;
        }

        /// <summary>
        /// Allows admin to set another user as an admin.
        /// </summary>
        /// <param name="userId">The ID of the user that will be set as admin.</param>
        /// <returns>The index list view.</returns>
        [HttpPost]
        public async Task<IActionResult> SetAdmin(string userId)
        {
            return await ModifyAdminPermissions(userId, true);
        }

        /// <summary>
        /// Allows admin to remove someone else's admin status.
        /// </summary>
        /// <param name="userId">The ID of the user whose admin permissions will be removed.</param>
        /// <returns>The index list view.</returns>
        [HttpPost]
        public async Task<IActionResult> RevokeAdmin(string userId)
        {
            return await ModifyAdminPermissions(userId, false);
        }

        /// <summary>
        /// Inner method to either set or revoke admin status.
        /// </summary>
        /// <param name="userId">The user who will be modified.</param>
        /// <param name="isAdmin">True if setting admin, false if revoking.</param>
        /// <returns>The index list view.</returns>
        private async Task<IActionResult> ModifyAdminPermissions(string userId, bool isAdmin)
        {
            //Must check for admin status
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            //App's current user
            IdentityUser currentUser = await GetCurrentUserAsync();

            //Do not proceed if not admin/webmaster
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            //Do not proceed if the user is attempting to modify themselves
            if (userId == currentUser.Id)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Can't modify your own permissions.";
                return Redirect("Index");
            }

            //gets the data of the user who will be modified
            UserDataModel userData = await _authRepository.GetUserDataByIdAsync(userId);
            IdentityUser user = await _authRepository.GetIdentityUserByIdAsync(userId);

            //can't modify a user who doesn't exist
            if (userData == null || user == null)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Invalid user ID.";
            }
            else
            {
                //do not grant admin status to a user who is banned
                if (user.LockoutEnd != null && isAdmin)
                {
                    TempData[TempDataHelper.FAILURE_DATA] = String.Format("Cannot grant admin status to user {0} - User is banned", userId);
                    return Redirect("Index");
                }

                //Update admin status in the database
                bool success = await _authRepository.UpdateUserAdminStatusAsync(userId, isAdmin);

                //Set message values based on success/failure
                if (success)
                {
                    TempData[TempDataHelper.SUCCESS_DATA] = "Successfully updated admin status for user " + userId;
                }
                else
                {
                    TempData[TempDataHelper.FAILURE_DATA] = "Operation Failed - Database Error";
                }
            }

            //Return to list view
            return Redirect("Index");
        }

        /// <summary>
        /// Allows an admin to ban a given user.
        /// </summary>
        /// <param name="userId">ID of the user who will be banned</param>
        /// <returns>The index list view</returns>
        [HttpPost]
        public async Task<IActionResult> BanUser(string userId)
        {
            return await SetUserBanStatus(userId, true);
        }

        /// <summary>
        /// Allows an admin to unban a user.
        /// </summary>
        /// <param name="userId">ID of the user who will be unbanned.</param>
        /// <returns>The index list view.</returns>
        [HttpPost]
        public async Task<IActionResult> UnbanUser(string userId)
        {
            return await SetUserBanStatus(userId, false);
        }

        /// <summary>
        /// Inner method allowing admin to ban/unban a user.
        /// </summary>
        /// <param name="userId">The user who will be modified.</param>
        /// <param name="isBanned">True to ban, false to unban.</param>
        /// <returns>The index list view.</returns>
        private async Task<IActionResult> SetUserBanStatus(string userId, bool isBanned)
        {
            //must check if user has the correct permissions
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            //the current application user
            IdentityUser currentUser = await GetCurrentUserAsync();

            //if user does not have correct permissions, do not proceed
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            //User should not be able to modify themselves
            if (userId == currentUser.Id)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Can't ban/unban yourself";
                return Redirect("Index");
            }
            
            //Get the user data for the given ID
            UserDataModel userData = await _authRepository.GetUserDataByIdAsync(userId);

            //Cannot ban a user that doesn't exist
            if (userData == null)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Invalid user ID";
            }
            else
            {
                //Perform database operation
                bool success = await _authRepository.SetUserBanStatusAsync(userId, isBanned);
                    
                //If user is an admin, demote them
                if (isBanned)
                {
                    await _authRepository.UpdateUserAdminStatusAsync(userId, false);
                }

                //Set message values based on the result of the operation
                if (success)
                {
                    TempData[TempDataHelper.SUCCESS_DATA] = String.Format("Successfully {0} user {1}", isBanned ? "banned" : "unbanned", userId);
                }
                else
                {
                    TempData[TempDataHelper.FAILURE_DATA] = "Operation Failed - Database Error";
                }
            }

            //Returns the index list view
            return Redirect("Index");
        }
    }
}
