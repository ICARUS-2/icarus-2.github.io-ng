﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MatteWebApplication.Data.Contexts;
using MatteWebApplication.Data.Repositories.AppData;
using MatteWebApplication.Data.Repositories.Auth;
using Microsoft.AspNetCore.Identity;
using MatteWebApplication.Helpers;
using MatteWebApplication.Models.Store;

namespace MatteWebApplication.Controllers
{
    /// <summary>
    /// Controller used to manage sales timers in the database and serve the views to interact with them.
    /// </summary>
    public class SaleTimerController : Controller
    {
        private readonly IAppDataRepository _appDataRepository;
        private readonly IAuthRepository _authRepository;
        private readonly UserManager<IdentityUser> _userManager;

        /// <summary>
        /// Takes in injected IAppDataRepository, IAuthRepository and UserManager instances and instantiates the controller.
        /// </summary>
        /// <param name="appDataRepository">Injected IAppDataRepository instance</param>
        /// <param name="authRepository">Injected IAuthRepository instance</param>
        /// <param name="userManager">Injected UserManager instance</param>
        public SaleTimerController(
            IAppDataRepository appDataRepository, 
            IAuthRepository authRepository,
            UserManager<IdentityUser> userManager)
        {
            _appDataRepository = appDataRepository;
            _authRepository = authRepository;   
            _userManager = userManager;
        }

        /// <summary>
        /// HTTP get retrieves the list view of all sales timers.
        /// </summary>
        /// <returns>The list view displaying all sales timers.</returns>
        public async Task<IActionResult> Index()
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
            {
                return View("AccessDenied");
            }

            List<SaleTimerModel> saleTimers = await _appDataRepository.GetSaleTimersListAsync();

            return View(saleTimers);
        }

        /// <summary>
        /// HTTP get retrieves the create form for a new sale timer.
        /// </summary>
        /// <returns>The view containing the form to create a new sale timer.</returns>
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
            {
                return View("AccessDenied");
            }

            return View();
        }

        /// <summary>
        /// HTTP post takes in a SaleTimerModel from the create form and adds it to the database.
        /// </summary>
        /// <param name="saleTimerModel">Model auto-generated from the form data.</param>
        /// <returns>Redirect to index action provided the model state was valid.</returns>
        [HttpPost]
        public async Task<IActionResult> Create(SaleTimerModel saleTimerModel)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
            {
                return View("AccessDenied");
            }

            if (!ModelState.IsValid)
            {
                return View();
            }

            bool success = await _appDataRepository.CreateSaleTimerAsync(saleTimerModel);

            if (success)
            {
                TempData[TempDataHelper.SUCCESS_DATA] = "Successfully created new sale timer.";
            }
            else
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Problem creating sale timer - Database error.";
            }

            return RedirectToAction("Index");
        }

        /// <summary>
        /// HTTP get fetches the deletion confirmation for a sale timer if it exists.
        /// </summary>
        /// <param name="id">The ID of the sale timer.</param>
        /// <returns>The confirmation form if the timer exists</returns>
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
            {
                return View("AccessDenied");
            }

            SaleTimerModel saleTimerModel = await _appDataRepository.GetSaleTimerByIdAsync(id);

            if (saleTimerModel == null)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Cannot delete a timer that does not exist.";
                return RedirectToAction("Index");
            }

            return View(saleTimerModel);
        }

        /// <summary>
        /// HTTP post takes in a form collection and an ID and deletes the corresponding sale timer.
        /// </summary>
        /// <param name="form">The confirmation form</param>
        /// <param name="id">The ID of the entry to be deleted</param>
        /// <returns>A redirect to the index action with a success/failure tempdata message.</returns>
        [HttpPost]
        public async Task<IActionResult> Delete(IFormCollection form, int id)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
            {
                return View("AccessDenied");
            }

            SaleTimerModel saleTimerModel = await _appDataRepository.GetSaleTimerByIdAsync(id);

            if (saleTimerModel == null)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Cannot delete a timer that does not exist.";
                return RedirectToAction("Index");
            }

            bool success = await _appDataRepository.DeleteSaleTimerAsync(id);

            if (success)
            {
                TempData[TempDataHelper.SUCCESS_DATA] = "Successfully deleted timer";
            }
            else
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Failed to delete timer - Database error";
            }

            return RedirectToAction("Index");
        }
    }
}
