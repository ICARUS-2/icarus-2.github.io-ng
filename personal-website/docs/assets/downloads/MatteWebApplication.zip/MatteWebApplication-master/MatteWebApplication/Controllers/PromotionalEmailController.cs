﻿using MatteWebApplication.Data.Repositories.AppData;
using MatteWebApplication.Data.Repositories.Auth;
using MatteWebApplication.Helpers;
using MatteWebApplication.Models.Communication;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;

namespace MatteWebApplication.Controllers
{
    /// <summary>
    /// Used for sending promotional emails to enrolled users
    /// </summary>
    public class PromotionalEmailController : Controller
    {
        private readonly IAppDataRepository _appDataRepository;
        private readonly IAuthRepository _authRepository;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IEmailSender _emailSender;

        public PromotionalEmailController(IAppDataRepository appDataRepository,
            IAuthRepository authRepository,
            IEmailSender emailSender,
            UserManager<IdentityUser> userManager)
        {
            _appDataRepository = appDataRepository;
            _authRepository = authRepository;
            _userManager = userManager;
            _emailSender = emailSender;
        }

        /// <summary>
        /// Redirects to Compose action
        /// </summary>
        /// <returns>Redirection to Compose action</returns>
        [HttpGet]
        public IActionResult Index()
        {
            return RedirectToAction("Compose");
        }

        /// <summary>
        /// HTTP get fetches the form to create a new promotional email.
        /// </summary>
        /// <returns>The view with the compose form.</returns>
        [HttpGet]
        public async Task<IActionResult> Compose()
        {
            //Cannot allow a base user to access an administrator-restricted view.
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            //Display access denied if basic user tries to access it.
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            return View();
        }

        /// <summary>
        /// HTTP post takes a promotional email and sends it out to the mailing list.
        /// </summary>
        /// <param name="email">The promotional email that will be sent to the mailing list.</param>
        /// <returns>Results screen detailing the success/failure of the operation.*</returns>
        [HttpPost]
        public async Task<IActionResult> Compose(PromotionalEmailModel email)
        {
            //Cannot allow a base user to access an administrator-restricted view.
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            //Display access denied if basic user tries to access it.
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            if (!ModelState.IsValid)
            {
                return View();
            }

            List<IdentityUser> mailingList = await _authRepository.GetPromotionalMailingListAsync();

            if (mailingList.Count == 0)
            {
                ViewData[TempDataHelper.WARNING_DATA] = "No emails sent - No active subscriptions";
            }
            else
            {
                try
                {
                    foreach (IdentityUser user in mailingList)
                    {
                        await _emailSender.SendEmailAsync(user.Email, email.Subject, email.Body);
                    }

                    ViewData[TempDataHelper.SUCCESS_DATA] = string.Format("Successfully sent promotional email to {0} users.", mailingList.Count);
                }
                catch(Exception ex) 
                {
                    ViewData[TempDataHelper.FAILURE_DATA] = "An error occured while sending email.";        
                };
            }

            return View("Result");
        }
    }
}
