﻿using MatteWebApplication.Data.Repositories.Auth;
using MatteWebApplication.Helpers;
using MatteWebApplication.Models.User;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Drawing;

namespace MatteWebApplication.Controllers
{
    /// <summary>
    /// Serves as a wrapper for the basic MVC controller which makes getting the current
    /// user easier.
    /// </summary>
    public class BaseController : Controller
    {
        protected IAuthRepository _authRepository;
        protected UserManager<IdentityUser> _userManager;

        /// <summary>
        /// Constructor takes in an IAuthRepository and a UserManager and sets them in the class
        /// </summary>
        /// <param name="authRepository">Used to manage auth data for the backend</param>
        /// <param name="userManager">Used to retrieve user data</param>
        public BaseController(IAuthRepository authRepository, UserManager<IdentityUser> userManager)
        {
            _authRepository = authRepository;
            _userManager = userManager;
        }

        /// <summary>
        /// Asynchronously gets the current application user
        /// </summary>
        /// <returns>The IdentityUser object representing the current user</returns>
        public async Task<IdentityUser> GetCurrentUserAsync()
        {
            return await _userManager.GetUserAsync(User);
        }

        public string GetRegion()
        {
            IRequestCookieCollection cookies = Request.Cookies;
            var region = cookies[RegionHelper.COOKIE_KEY];

            if (region == null)
            {
                region = RegionHelper.DEFAULT_REGION.ToString();
            }
    
            return region;
        }
    }
}
