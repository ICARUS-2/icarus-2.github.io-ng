﻿using MatteWebApplication.Data.Repositories.Auth;
using MatteWebApplication.Helpers;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace MatteWebApplication.Controllers
{
    public class CollectionsController : BaseController
    {
        public CollectionsController(IAuthRepository authRepository, UserManager<IdentityUser> userManager) : base(authRepository, userManager)
        {
        }

        [Route("/collections")]
        public IActionResult Index()
        {
            return View();
        }

        [Route("collections/best-sellers")]
        public IActionResult BestSellers()
        {
            ViewData[RegionHelper.COOKIE_KEY] = GetRegion();
            return View("ViewCollection", CollectionHelper.CollectionType.BestSellers);
        }

        [Route("collections/featured")]
        public IActionResult Featured()
        {
            ViewData[RegionHelper.COOKIE_KEY] = GetRegion();
            return View("ViewCollection", CollectionHelper.CollectionType.Featured);
        }

        [Route("collections/new-arrivals")]
        public IActionResult NewArrivals()
        {
            ViewData[RegionHelper.COOKIE_KEY] = GetRegion();
            return View("ViewCollection", CollectionHelper.CollectionType.NewArrivals);
        }
    }
}
