﻿using MatteWebApplication.Data.Repositories.AppData;
using MatteWebApplication.Data.Repositories.Auth;
using MatteWebApplication.Helpers;
using MatteWebApplication.Models.Communication;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace MatteWebApplication.Controllers
{
    /// <summary>
    /// Controller used to manage contact form receiver data.
    /// </summary>
    public class ContactManagerController : Controller
    {
        private readonly IAuthRepository _authRepository;
        private readonly IAppDataRepository _appDataRepository;
        private readonly UserManager<IdentityUser> _userManager;

        /// <summary>
        /// Takes in injected IAuthRepository, IAppDataRepository and IdentityUser UserManager to instantiate controller.
        /// </summary>
        /// <param name="authRepository">Injected IAuthRepository instance</param>
        /// <param name="appDataRepository">Injected IAppDataRepository instance</param>
        /// <param name="userManager">Injected IdentityUser UserManager instance</param>
        public ContactManagerController(IAuthRepository authRepository, IAppDataRepository appDataRepository ,UserManager<IdentityUser> userManager)
        {
            _authRepository = authRepository;
            _appDataRepository = appDataRepository;
            _userManager = userManager;
        }

        /// <summary>
        /// HTTP get used to retrieve the list of contact form receivers
        /// </summary>
        /// <returns>The list view with all of the available contact receivers as its model</returns>
        [Route("ContactManager")]
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
                return View("AccessDenied");

            List<ContactReceiverModel> contacts = await _appDataRepository.GetContactReceiversAsync();

            return View(contacts);
        }

        /// <summary>
        /// HTTP get used to retrieve the view to add a new contact receiver.
        /// </summary>
        /// <returns>The view with the form to create a new contact receiver.</returns>
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
                return View("AccessDenied");

            return View();
        }

        /// <summary>
        /// HTTP post used to create new contact receiver data.
        /// </summary>
        /// <param name="contactReceiverModel">The auto-generated model from the form.</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Create(ContactReceiverModel contactReceiverModel)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
                return View("AccessDenied");

            if (!ModelState.IsValid)
                return View();

            bool success = await _appDataRepository.CreateContactReceiverAsync(contactReceiverModel);

            if (success)
            {
                TempData[TempDataHelper.SUCCESS_DATA] = "Successfully created contact receiver with email " + contactReceiverModel.Email;
            }
            else
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Failed to create receiver - Database error";
            }


            return RedirectToAction("Index");
        }

        /// <summary>
        /// HTTP get used to retrieve a deletion confirmation form for a contact receiver
        /// </summary>
        /// <param name="id">The ID of the contact receiver that will be deleted</param>
        /// <returns>The confirmation for the deletion of the contact receiver corresponding to the passed ID</returns>
        [Route("ContactManager/Delete/{id}")]
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
                return View("AccessDenied");

            ContactReceiverModel contactReceiverModel = await _appDataRepository.GetContactReceiverByIdAsync(id);

            if (contactReceiverModel == null)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Contact receiver does not exist";
                return RedirectToAction("Index");
            }

            return View(contactReceiverModel);
        }

        /// <summary>
        /// HTTP post used to delete a contact receiver based on its ID
        /// </summary>
        /// <param name="id">The ID of the contact receiver to be deleted</param>
        /// <param name="form">The form data from the view</param>
        /// <returns>A redirect to the list view with a success/failure message based on the deletion result</returns>
        [Route("ContactManager/Delete/{id}")]
        [HttpPost]
        public async Task<IActionResult> Delete(int id, IFormCollection form)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
                return View("AccessDenied");

            bool success = await _appDataRepository.DeleteContactReceiverAsync(id);

            if (success)
            {
                TempData[TempDataHelper.SUCCESS_DATA] = "Successfully deleted contact receiver";
            }
            else
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Deletion failed";
            }

            return RedirectToAction("Index");
        }
    }
}
