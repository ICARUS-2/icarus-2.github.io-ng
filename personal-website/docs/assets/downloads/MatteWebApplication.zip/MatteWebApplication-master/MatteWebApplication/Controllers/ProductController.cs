﻿using MatteWebApplication.Data.Repositories.AppData;
using MatteWebApplication.Data.Repositories.Auth;
using MatteWebApplication.Helpers;
using MatteWebApplication.Models.Store;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.IO;

namespace MatteWebApplication.Controllers
{
    /// <summary>
    /// Controller used to create, read, update and delete product data in the store's database
    /// </summary>
    public class ProductController : BaseController
    {
        private readonly IAppDataRepository _appDataRepository;
        private readonly IAuthRepository _authRepository;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IWebHostEnvironment _webHostEnvironment;

        /// <summary>
        /// Takes in injected IAppDataRepository, IAuthRepository, IdentityUser UserManager and IWebHostEnvironment instances to instantiate the controller.
        /// </summary>
        /// <param name="appDataRepository"></param>
        /// <param name="authRepository"></param>
        /// <param name="userManager"></param>
        /// <param name="webHostEnvironment"></param>
        public ProductController(
            IAppDataRepository appDataRepository, 
            IAuthRepository authRepository, 
            UserManager<IdentityUser> userManager,
            IWebHostEnvironment webHostEnvironment) : base(authRepository, userManager)
        {
            _appDataRepository = appDataRepository;
            _authRepository = authRepository;   
            _userManager = userManager;
            _webHostEnvironment = webHostEnvironment;
        } 

        private string GetRootPath()
        {
            return _webHostEnvironment.WebRootPath;
        }

        /// <summary>
        /// Gets the list page of all the products.
        /// </summary>
        /// <returns>The products view with the list of all products as its model.</returns>
        [Route("/product")]
        public async Task<IActionResult> Index()
        {
            string region = GetRegion();

            ViewData[RegionHelper.COOKIE_KEY] = region;

            return View(await _appDataRepository.GetProductsListAsync());
        }

        /// <summary>
        /// Gets the view page for a specific product.
        /// </summary>
        /// <param name="id">The ID of the product to be viewed.</param>
        /// <returns>The product view if the product exists, 404 if not.</returns>
        [HttpGet]
        [Route("/product/{id}")]
        public async Task<IActionResult> ViewProduct(int id)
        {
            Product product = await _appDataRepository.GetProductByIdAsync(id);

            if (product == null)
            {
                return NotFound();
            }

            string region = GetRegion();

            ViewData[RegionHelper.COOKIE_KEY] = region;

            return View(product);
        }

        /// <summary>
        /// HTTP get retrieves the creation form for a new product.
        /// </summary>
        /// <returns>The view with the form to create a new product.</returns>
        [HttpGet]
        [Route("/product/create")]
        public async Task<IActionResult> Create()
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
            {
                return View("AccessDenied");
            }

            List<Category> categories = await _appDataRepository.GetCategoriesListAsync();
            if (categories.Count == 0)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "You must have at least one category to create a product";
                return RedirectToAction("Index");
            }

            return View();
        }

        /// <summary>
        /// HTTP post takes in the data for a new product and adds it into the database, and adds the product's images to the file structure.
        /// </summary>
        /// <param name="imageFiles">The uploaded images of the product.</param>
        /// <param name="product">The product model auto-generated from the form data.</param>
        /// <param name="form">The submitted form data.</param>
        /// <returns>A redirect to the index list with the success/failure message.</returns>
        [HttpPost]
        [Route("/product/create")]
        public async Task<IActionResult> Create(IFormFileCollection imageFiles, Product product, IFormCollection form)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
            {
                return View("AccessDenied");
            }

            int categoryId = int.Parse(form["category"]);

            List<Category> categories = await _appDataRepository.GetCategoriesListAsync();
            if (categories.Count == 0)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "You must have at least one category to create a product";
                return RedirectToAction("Index");
            }

            if (!ModelState.IsValid)
            {
                return View();
            }

            product.AdditionalInfo = product.AdditionalInfo == null ? string.Empty : product.AdditionalInfo;
            product.YoutubeLinks = product.YoutubeLinks == null ? string.Empty : product.YoutubeLinks;

            StringBuilder errors = new StringBuilder();

            //Verify that all images are PNG
            foreach (IFormFile f in imageFiles) 
            {
                if (f.ContentType != "image/png")
                {
                    errors.AppendLine("Only PNG images are supported");
                    break;
                }
            }

            //Check that the corresponding category exists
            Category categoryFromDb = await _appDataRepository.GetCategoryByIdAsync(categoryId);

            //If the product has no category, then don't add it
            if (categoryFromDb == null)
            {
                errors.AppendLine("Category does not exist\n");
            }

            if (errors.Length != 0)
            {
                ViewData[TempDataHelper.FAILURE_DATA] = errors.ToString();
                return View();
            }

            //Must have category to insert into database
            product.Category = categoryFromDb;

            //Boolean represents if the product was successfully added
            bool productAddSuccess = await _appDataRepository.CreateProductAsync(product);

            //Ensure maximum two decimal places
            product.CadSalePrice = Math.Round(product.CadSalePrice, 2);
            product.CadPrice = Math.Round(product.CadPrice, 2);

            product.UsdSalePrice = Math.Round(product.UsdSalePrice, 2);
            product.UsdPrice = Math.Round(product.UsdPrice, 2);

            product.AudSalePrice = Math.Round(product.AudSalePrice, 2);
            product.AudPrice = Math.Round(product.AudPrice, 2);

            product.EurSalePrice = Math.Round(product.EurSalePrice, 2);
            product.EurPrice = Math.Round(product.EurPrice, 2);

            product.GbpSalePrice = Math.Round(product.GbpSalePrice, 2);
            product.GbpPrice = Math.Round(product.GbpPrice, 2);

            //If we got this far, then proceed with the image creation
            if (productAddSuccess)
            {
                try
                {
                    foreach (IFormFile f in imageFiles)
                    {
                        //Upload the image via the CDN helper
                        string fullImagePath = await CDNHelper.UploadImageAsync(f, product.Id, GetRootPath());

                        //Image data will be stored in database to retrieve it
                        StoreImage img = new StoreImage() { PathToImage = fullImagePath, ProductId = product.Id, Title = f.FileName };
                        
                        //Save that image data in DB
                        await _appDataRepository.CreateStoreImageDataAsync(img);
                    }
                }
                catch (Exception ex)
                {
                    ViewData[TempDataHelper.FAILURE_DATA] = "Upload Error";
                    return View();
                }

                TempData[TempDataHelper.SUCCESS_DATA] = string.Format("Successfully created product {0} with ID {1}", product.Name, product.Id);
            }
            else
            {
                ViewData[TempDataHelper.FAILURE_DATA] = "Product not created - database error";
                return View();
            }

            return RedirectToAction("Index");
        }

        /// <summary>
        /// HTTP get retrieves the edit form for a product with a given ID.
        /// </summary>
        /// <param name="id">The ID of the product to be edited.</param>
        /// <returns>The edit form view with the retrieved product as its model.</returns>
        [HttpGet]
        [Route("product/edit/{id}")]
        public async Task<IActionResult> Edit(int id)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
            {
                return View("AccessDenied");
            }

            Product product = await _appDataRepository.GetProductByIdAsync(id);

            if (product == null)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Product not found";
                return RedirectToAction("Index");
            }

            List<StoreImage> productImages = await _appDataRepository.GetStoreImagesByProductIdAsync(id);

            if (productImages != null)
            {
                product.StoreImages = productImages;
            }

            return View(product);
        }

        /// <summary>
        /// HTTP post takes edited data about a product and updates it in the database.
        /// </summary>
        /// <param name="imageFiles">The newly uploaded image files.</param>
        /// <param name="product">The product model auto-generated from the form.</param>
        /// <param name="form">The form containing all of the updated product data.</param>
        /// <returns></returns>
        [HttpPost]
        [Route("product/edit/{id}")]
        public async Task<IActionResult> Edit(IFormFileCollection imageFiles, Product product, IFormCollection form)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);

            if (!isElevated)
            {
                return View("AccessDenied");
            }

            StringBuilder errors = new StringBuilder();

            int categoryId = int.Parse(form["category"]);

            //Check that the corresponding category exists
            Category categoryFromDb = await _appDataRepository.GetCategoryByIdAsync(categoryId);
            product.Category = categoryFromDb;

            //If the product has no category, then don't add it
            if (categoryFromDb == null)
            {
                errors.AppendLine("Category does not exist\n");
            }

            //Verify that all images are PNG
            foreach (IFormFile f in imageFiles)
            {
                if (f.ContentType != "image/png")
                {
                    errors.AppendLine("Only PNG images are supported");
                    break;
                }
            }

            if (!ModelState.IsValid)
            {
                return View(product);
            }

            if (errors.Length != 0)
            {
                ViewData[TempDataHelper.FAILURE_DATA] = errors.ToString();
                return View(product);
            }

            Product productToEdit = await _appDataRepository.GetProductByIdAsync(product.Id);

            if (productToEdit == null)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Product does not exist";
                return RedirectToAction("Index");
            }

            //Ensure maximum two decimal places
            product.CadSalePrice = Math.Round(product.CadSalePrice, 2);
            product.CadPrice = Math.Round(product.CadPrice, 2);

            product.UsdSalePrice = Math.Round(product.UsdSalePrice, 2);
            product.UsdPrice = Math.Round(product.UsdPrice, 2);

            product.AudSalePrice = Math.Round(product.AudSalePrice, 2);
            product.AudPrice = Math.Round(product.AudPrice, 2);

            product.EurSalePrice = Math.Round(product.EurSalePrice, 2);
            product.EurPrice = Math.Round(product.EurPrice, 2);

            product.GbpSalePrice = Math.Round(product.GbpSalePrice, 2);
            product.GbpPrice = Math.Round(product.GbpPrice, 2);

            productToEdit.Description = product.Description;
            productToEdit.AdditionalInfo = product.AdditionalInfo == null ? string.Empty : product.AdditionalInfo;
            productToEdit.Link = product.Link;
            productToEdit.YoutubeLinks = product.YoutubeLinks == null ? string.Empty : product.YoutubeLinks;
            productToEdit.Category = product.Category;
            productToEdit.CadPrice = product.CadPrice;
            productToEdit.CadSalePrice = product.CadSalePrice;
            productToEdit.UsdPrice = product.UsdPrice;
            productToEdit.UsdSalePrice = product.UsdSalePrice;
            productToEdit.AudPrice = product.AudPrice;
            productToEdit.AudSalePrice = product.AudSalePrice;
            productToEdit.EurPrice = product.EurPrice;
            productToEdit.EurSalePrice = product.EurSalePrice;
            productToEdit.GbpPrice = product.GbpPrice;
            productToEdit.GbpSalePrice = product.GbpSalePrice;
            productToEdit.IsOnSale = product.IsOnSale;
            productToEdit.Name = product.Name;
            productToEdit.Category = categoryFromDb;
            productToEdit.IsBestSeller = product.IsBestSeller;
            productToEdit.IsFeatured = product.IsFeatured;
            productToEdit.IsNewArrival = product.IsNewArrival;


            await _appDataRepository.UpdateProductAsync(productToEdit);

            //image stuff
            try
            {
                foreach (IFormFile f in imageFiles)
                {
                    //Upload the image via the CDN helper
                    string fullImagePath = await CDNHelper.UploadImageAsync(f, product.Id, GetRootPath());

                    //Image data will be stored in database to retrieve it
                    StoreImage img = new StoreImage() { PathToImage = fullImagePath, ProductId = product.Id, Title = f.FileName };

                    //Save that image data in DB
                    await _appDataRepository.CreateStoreImageDataAsync(img);
                }
            }
            catch (Exception ex)
            {
                ViewData[TempDataHelper.FAILURE_DATA] = "Upload Error";
                return View(product);
            }

            List<string> deleteImageKeys = form.Keys.Where(k => k.StartsWith(CDNHelper.DeleteImagePrefix)).ToList();

            foreach (string s in deleteImageKeys)
            {
                int imageIdToDelete = int.Parse(s.Split("_")[1]);
                StoreImage imageData = await _appDataRepository.GetStoreImageByIdAsync(imageIdToDelete);

                if (imageData == null)
                    continue;

                await _appDataRepository.DeleteStoreImageByIdAsync(imageIdToDelete);
                CDNHelper.DeleteImage(imageData.PathToImage);
            }


            TempData[TempDataHelper.SUCCESS_DATA] = string.Format("Successfully updated product {0} [ID {1}]", product.Name, product.Id);
            return RedirectToAction("Index");
        }

        /// <summary>
        /// HTTP get retrieves the delete confirmation form for a given product.
        /// </summary>
        /// <param name="id">The ID of the product to retrieve the info for.</param>
        /// <returns>The delete confirmation view for the product.</returns>
        [HttpGet]
        [Route("product/delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            Product product = await _appDataRepository.GetProductByIdAsync(id);

            if (product == null)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Product does not exist";
                return RedirectToAction("Index");
            }
            return View(product);
        }

        /// <summary>
        /// HTTP post deletes a product with a given ID from the database.
        /// </summary>
        /// <param name="form">The confirmation form data.</param>
        /// <param name="id">The ID of the product that will be deleted.</param>
        /// <returns>A redirect to the index list with a success/failure message.</returns>
        [HttpPost]
        [Route("product/delete/{id}")]
        public async Task<IActionResult> Delete(IFormCollection form, int id)
        {
            bool isElevated = await _authRepository.UserIsMasterOrAdminAsync(User, _userManager);
            if (!isElevated)
            {
                return View("AccessDenied");
            }

            Product product = await _appDataRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Product does not exist";
                return RedirectToAction("Index");
            }

            await _appDataRepository.DeleteReviewsForProductAsync(id);

            bool success = await _appDataRepository.DeleteProductAsync(id);

            if (success)
            {
                CDNHelper.DeleteAllProductImages(_webHostEnvironment.WebRootPath, id);
                TempData[TempDataHelper.SUCCESS_DATA] = "Successfully deleted product " + product.Name;
            }
            else
            {
                TempData[TempDataHelper.FAILURE_DATA] = "Failed to delete product - Database error";
            }

            return RedirectToAction("Index");
        }
    }
}
