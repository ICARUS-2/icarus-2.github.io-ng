﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MatteWebApplication.Data.Migrations
{
    public partial class masterpasswordsecret : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1",
                columns: new[] { "ConcurrencyStamp", "NormalizedEmail", "PasswordHash", "SecurityStamp" },
                values: new object[] { "f8baafc5-b6b8-4a1b-a248-47bd0b3a8c9d", "EBRIFFETT01@GMAIL.COM", "AQAAAAEAACcQAAAAEOB//7s7BmrxfMvNHpgEbS6BFaGRfgwXU4d/f7ayVK4oUkcKMiceVLZW3N0+ILDPOQ==", "591b787e-6029-48f1-82ed-1751a1e1f6e2" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1",
                columns: new[] { "ConcurrencyStamp", "NormalizedEmail", "PasswordHash", "SecurityStamp" },
                values: new object[] { "3aaf768e-cc4d-413f-b8dd-37b5cd79ce62", "EBRIFFETT01@GMAIL>COM", "AQAAAAEAACcQAAAAECPGKcMTvJSIGfC6FTHJKaSAjH8qBFdTlMyMUF2Sl+sMq6FFD6HzXZyEV97rqQFs2A==", "e2cf1872-c255-47dd-ab84-2db1cb1e151d" });
        }
    }
}
