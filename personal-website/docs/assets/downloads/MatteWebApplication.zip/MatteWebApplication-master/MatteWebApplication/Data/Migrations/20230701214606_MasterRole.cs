﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MatteWebApplication.Data.Migrations
{
    public partial class MasterRole : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsMaster",
                table: "UserDataModels",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsMaster",
                table: "UserDataModels");
        }
    }
}
