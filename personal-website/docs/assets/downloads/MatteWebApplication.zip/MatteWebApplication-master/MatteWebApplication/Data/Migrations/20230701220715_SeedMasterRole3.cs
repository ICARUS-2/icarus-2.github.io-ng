﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MatteWebApplication.Data.Migrations
{
    public partial class SeedMasterRole3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1",
                columns: new[] { "ConcurrencyStamp", "NormalizedEmail", "PasswordHash", "SecurityStamp" },
                values: new object[] { "3aaf768e-cc4d-413f-b8dd-37b5cd79ce62", "EBRIFFETT01@GMAIL>COM", "AQAAAAEAACcQAAAAECPGKcMTvJSIGfC6FTHJKaSAjH8qBFdTlMyMUF2Sl+sMq6FFD6HzXZyEV97rqQFs2A==", "e2cf1872-c255-47dd-ab84-2db1cb1e151d" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1",
                columns: new[] { "ConcurrencyStamp", "NormalizedEmail", "PasswordHash", "SecurityStamp" },
                values: new object[] { "c191106e-9305-4cb5-a22d-9099e79b8da8", null, "AQAAAAEAACcQAAAAEAC4SGj/5wmw/UapBAmGnw6wK88pzywGw0MNUw5IdL1qdPyKxp/D2hNNohQKb8hfYg==", "2dbd2ed0-f3a9-45d6-abec-482e6c445c4c" });
        }
    }
}
