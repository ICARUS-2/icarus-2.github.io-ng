﻿using MatteWebApplication.Data.Contexts;
using MatteWebApplication.Helpers;
using MatteWebApplication.Models.Communication;
using MatteWebApplication.Models.Store;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using NuGet.Protocol;
using System.Reflection.Metadata.Ecma335;

namespace MatteWebApplication.Data.Repositories.AppData
{
    /// <summary>
    /// Repository used to handle the application database's interactions. Implements IAppDataRepository interface.
    /// </summary>
    public class AppDataRepository : IAppDataRepository
    {
        private readonly AppDatabaseContext _context;

        /// <summary>
        /// Takes in the AppDatabaseContext to instantiate the repository.
        /// </summary>
        /// <param name="ctx">The AppDatabaseContext with the connection configured.</param>
        public AppDataRepository(AppDatabaseContext ctx)
        {
            _context = ctx;
        }

        /// <summary>
        /// Asynchronously adds a new category to the database.
        /// </summary>
        /// <param name="category">The category to be added.</param>
        /// <returns>True/False based on the success of the operation.</returns>
        public async Task<bool> AddCategoryAsync(Category category)
        {
            try
            {
                await _context.Categories.AddAsync(category);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Asynchronously retrieves the list of all categories in the database.
        /// </summary>
        /// <returns>The list of all of the store's categories.</returns>
        public async Task<List<Category>> GetCategoriesListAsync()
        {
            return await _context.Categories.ToListAsync();
        }

        /// <summary>
        /// Asynchronously retrieves a category based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the category we are looking for.</param>
        /// <returns>The category if it exists, null if not.</returns>
        public async Task<Category> GetCategoryByIdAsync(int id)
        {
            return await _context.Categories.Where(c => c.Id == id).FirstOrDefaultAsync();
        }

        /// <summary>
        /// Takes a category and updates its data in the database.
        /// </summary>
        /// <param name="category">The category containing the updated data.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> UpdateCategoryAsync(Category category)
        {
            try
            {
                _context.Categories.Update(category);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Deletes a category and the products associated with it from the database.
        /// </summary>
        /// <param name="categoryId">The ID of the category that will be deleted alongside its products.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> DeleteCategoryAndProductsAsync(int categoryId)
        {
            try
            {
                Category category = await GetCategoryByIdAsync(categoryId);

                if (category == null)
                    return false;

                List<Product> productsByCategory = await GetProductsByCategoryAsync(categoryId);

                foreach (Product product in productsByCategory)
                {
                    await DeleteAllProductImageDataAsync(product.Id);
                }

                _context.Products.RemoveRange(productsByCategory);

                _context.Categories.Remove(category);

                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Asynchronously retrieves the list of products in the database.
        /// </summary>
        /// <returns>The list of all the store's products.</returns>
        public async Task<List<Product>> GetProductsListAsync()
        {
            return await _context.Products.ToListAsync();
        }

        /// <summary>
        /// Asynchronously retrieves a product's data based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the product whose data is needed.</param>
        /// <returns>The product object if it exists, null if not.</returns>
        public async Task<Product> GetProductByIdAsync(int id)
        {
            return await _context.Products.Where(p => p.Id == id).FirstOrDefaultAsync();
        }

        /// <summary>
        /// Asynchronously gets all of the products for a given category.
        /// </summary>
        /// <param name="categoryId">The category whose products we are searching for.</param>
        /// <returns>The list of products if the category exists, an empty list if the category has no products, or null if the category does not exist.</returns>
        public async Task<List<Product>> GetProductsByCategoryAsync(int categoryId)
        {
            return await _context.Products.Where(p => p.Category.Id == categoryId).ToListAsync();
        }


        /// <summary>
        /// Asynchronously gets all of the products that are listed as best sellers.
        /// </summary>
        /// <returns>A list of all of the best sellers</returns>
        public async Task<List<Product>> GetBestSellerProductsAsync()
        {
            return await _context.Products.Where(p => p.IsBestSeller).ToListAsync();
        }

        /// <summary>
        /// Asynchronously gets all of the products marked as featured.
        /// </summary>
        /// <returns>A list of all featured products.</returns>
        public async Task<List<Product>> GetFeaturedProductsAsync()
        {
            return await _context.Products.Where(p => p.IsFeatured).ToListAsync();
        }

        /// <summary>
        /// Asynchrounously gets all of the products marked as new arrivals.
        /// </summary>
        /// <returns>A list of all new arrival products.</returns>
        public async Task<List<Product>> GetNewArrivalProductsAsync()
        {
            return await _context.Products.Where(p => p.IsNewArrival).ToListAsync();
        }


        /// <summary>
        /// Asynchronously creates a new product entry in the database.
        /// </summary>
        /// <param name="product">The product that will be added to the database.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> CreateProductAsync(Product product)
        {
            try
            {
                await _context.Products.AddAsync(product);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Asynchronously adds new image data to the database.
        /// </summary>
        /// <param name="img">The image data that will be added.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> CreateStoreImageDataAsync(StoreImage img)
        {
            try
            {
                await _context.StoreImages.AddAsync(img);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Asynchronously updates an existing product's data in the database.
        /// </summary>
        /// <param name="product">The product containing the data that will be updated.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> UpdateProductAsync(Product product)
        {
            try
            {
                _context.Products.Update(product);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Asynchronously deletes a product based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the product that will be deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> DeleteProductAsync(int id)
        {
            try
            {
                Product p = await GetProductByIdAsync(id);

                if (p == null)
                    return false;

                await DeleteAllProductImageDataAsync(id);
                _context.Products.Remove(p);
                await _context.SaveChangesAsync();

                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Asynchronously retrieves a product's imaage data based on the passed product ID.
        /// </summary>
        /// <param name="productId">The ID of the product whose images we are looking for.</param>
        /// <returns>The list of images for that product.</returns>
        public async Task<List<StoreImage>> GetStoreImagesByProductIdAsync(int productId)
        {
            return await _context.StoreImages.Where(img => img.ProductId == productId).ToListAsync();
        }

        /// <summary>
        /// Asynchronously retrieves a single store image based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the image we are searching for.</param>
        /// <returns>The image data if it exists, null if not.</returns>
        public async Task<StoreImage> GetStoreImageByIdAsync(int id)
        {
            return await _context.StoreImages.Where(img => img.Id == id).FirstOrDefaultAsync();
        }

        /// <summary>
        /// Asynchronously deletes a store image in the database based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the image being deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> DeleteStoreImageByIdAsync(int id)
        {
            try
            {
                StoreImage image = await GetStoreImageByIdAsync(id);

                if (image == null)
                    return false;

                _context.StoreImages.Remove(image);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Asynchronously deletes all of a product's images in the database.
        /// </summary>
        /// <param name="productId">The ID of the product whose images will be deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> DeleteAllProductImageDataAsync(int productId)
        {
            try
            {
                List<StoreImage> storeImagesForProduct = await GetStoreImagesByProductIdAsync(productId);

                _context.StoreImages.RemoveRange(storeImagesForProduct);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Asynchronously retrieves the list of all contact receivers in the database.
        /// </summary>
        /// <returns>The list of all existing contact receivers.</returns>
        public async Task<List<ContactReceiverModel>> GetContactReceiversAsync()
        {
            return await _context.ContactReceivers.ToListAsync();
        }

        /// <summary>
        /// Creates new contact receiver entry in the database.
        /// </summary>
        /// <param name="contactReceiverModel">The data of the contact receiver that will be added.</param>
        /// <returns>True/false based on the result of the operation</returns>
        public async Task<bool> CreateContactReceiverAsync(ContactReceiverModel contactReceiverModel)
        {
            try
            {
                await _context.ContactReceivers.AddAsync(contactReceiverModel);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Asynchronously retrieves contact receiver data associated with the passed ID.
        /// </summary>
        /// <param name="id">The ID of the contact receiver whose data will be retrieved.</param>
        /// <returns>The contact data if it exists, null if it does not.</returns>
        public async Task<ContactReceiverModel> GetContactReceiverByIdAsync(int id)
        {
            return await _context.ContactReceivers.Where(c => c.Id == id).FirstOrDefaultAsync();
        }

        /// <summary>
        /// Asynchronously deletes a contact receiver's data associated with the passed ID.
        /// </summary>
        /// <param name="id">The ID of the contact receiver whose data will be deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> DeleteContactReceiverAsync(int id)
        {
            try
            {
                ContactReceiverModel contactReceiverModel = await GetContactReceiverByIdAsync(id);
                if (contactReceiverModel == null)
                    return false;

                _context.ContactReceivers.Remove(contactReceiverModel);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Asynchronously creates a new SaleTimerModel in the database.
        /// </summary>
        /// <param name="saleTimerModel">The model to be added in the database.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> CreateSaleTimerAsync(SaleTimerModel saleTimerModel)
        {
            try
            {
                await _context.SaleTimers.AddAsync(saleTimerModel);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Asynchronously gets a sale timer from the database by its ID.
        /// </summary>
        /// <param name="id">The ID of the sale timer to be retrieved.</param>
        /// <returns>The sale timer if it exists, null if it does not.</returns>
        public async Task<SaleTimerModel> GetSaleTimerByIdAsync(int id)
        {
            return await _context.SaleTimers.Where(s => s.Id == id).FirstOrDefaultAsync();
        }

        /// <summary>
        /// Asynchronously gets a list of all sale timers.
        /// </summary>
        /// <returns></returns>
        public async Task<List<SaleTimerModel>> GetSaleTimersListAsync()
        {
            return _context.SaleTimers.ToList();
        }

        /// <summary>
        /// Asynchronously deletes a sale timer by ID
        /// </summary>
        /// <param name="id">The ID of the sale timer to be deleted.</param>
        /// <returns>True/false based on the result of the operation</returns>
        public async Task<bool> DeleteSaleTimerAsync(int id)
        {
            try
            {
                SaleTimerModel saleTimer = await GetSaleTimerByIdAsync(id);

                if (saleTimer == null)
                {
                    return false;
                }

                _context.SaleTimers.Remove(saleTimer);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Asynchronously creates a new review for a product with a given ID.
        /// </summary>
        /// <param name="review">The review to be added.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> CreateReviewAsync(Review review)
        {
            try
            {
                Product product = await GetProductByIdAsync(review.ProductId);
                if (product == null)
                {
                    return false;
                }

                await _context.Reviews.AddAsync(review);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Asynchronously gets a review based on its ID.
        /// </summary>
        /// <param name="id">The review ID.</param>
        /// <returns>The review associated with the ID.</returns>
        public async Task<Review> GetReviewByIdAsync(int id)
        {
            return await _context.Reviews.Where(r => r.Id == id).FirstOrDefaultAsync();
        }

        /// <summary>
        /// Asynchronously takes a review and updates it.
        /// </summary>
        /// <param name="review">The review to be updated.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> UpdateReviewAsync(Review review)
        {
            try
            {
                Product product = await GetProductByIdAsync(review.ProductId);
                if (product == null)
                {
                    return false;
                }

                _context.Reviews.Update(review);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Asynchronously deletes a review based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the review to be deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public async Task<bool> DeleteReviewAsync(int id)
        {
            try
            {
                Review review = await GetReviewByIdAsync(id);
                if (review == null)
                {
                    return false;
                }

                _context.Reviews.Remove(review);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Asynchronously retrieves a list of reviews for a given product.
        /// </summary>
        /// <param name="productId">The ID of the product whose reviews will be retrieved.</param>
        /// <returns>The list of reviews for that product.</returns>
        public async Task<List<Review>> GetReviewsForProductAsync(int productId)
        {
            return await _context.Reviews.Where(r => r.ProductId == productId).ToListAsync();
        }

        public async Task<bool> DeleteReviewsForProductAsync(int productId)
        {
            try
            {
                List<Review> reviews = await GetReviewsForProductAsync(productId);

                foreach(Review r in reviews)
                {
                    _context.Reviews.Remove(r);
                }

                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return false;
            }

            return true;
        }
    }
}
