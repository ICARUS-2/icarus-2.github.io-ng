﻿using MatteWebApplication.Models.Communication;
using MatteWebApplication.Models.Store;
using Microsoft.EntityFrameworkCore;

namespace MatteWebApplication.Data.Contexts
{
    /// <summary>
    /// The context used for interacting with the app's database.
    /// </summary>
    public class AppDatabaseContext : DbContext
    {
        /// <summary>
        /// The Categories table in the database.
        /// </summary>
        public DbSet<Category> Categories { get; set; }

        /// <summary>
        /// The Products table in the database.
        /// </summary>
        public DbSet<Product> Products { get; set; }

        /// <summary>
        /// The StoreImages table in the database.
        /// </summary>
        public DbSet<StoreImage> StoreImages { get; set; }

        /// <summary>
        /// The Reviews table in the database.
        /// </summary>
        public DbSet<Review> Reviews { get; set; }

        /// <summary>
        /// The ContactReceivers table in the database.
        /// </summary>
        public DbSet<ContactReceiverModel> ContactReceivers { get; set; }

        /// <summary>
        /// The SaleTimers table in the database
        /// </summary>
        public DbSet<SaleTimerModel> SaleTimers { get; set; }

        /// <summary>
        /// Takes an AppDatabaseContext DbContextOptions to instantiate the new context.
        /// </summary>
        /// <param name="options">The DbContextOptions to configure the connection.</param>
        public AppDatabaseContext(DbContextOptions<AppDatabaseContext> options) : base(options)
        {

        }
    }
}
