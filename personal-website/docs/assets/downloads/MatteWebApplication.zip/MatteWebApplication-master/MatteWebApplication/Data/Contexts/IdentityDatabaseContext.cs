﻿using MatteWebApplication.Models.User;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace MatteWebApplication.Data.Contexts
{
    /// <summary>
    /// The Identity database context used to handle users/authentication.
    /// </summary>
    public class IdentityDatabaseContext : IdentityDbContext
    {
        private readonly IConfiguration _config;

        /// <summary>
        /// The UserData table (handles user data that lies outside the basic IdentityUser).
        /// </summary>
        public DbSet<UserDataModel> UserDataModels { get; set; }

        /// <summary>
        /// Takes in the context options and an IConfiguration instance to create the context.
        /// </summary>
        /// <param name="options">The options used to configure the database connection.</param>
        /// <param name="config">Used to configure the database seeding process.</param>
        public IdentityDatabaseContext(DbContextOptions<IdentityDatabaseContext> options, IConfiguration config)
            : base(options)
        {
            _config = config;
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            SeedMasterAdmin(builder);
        }

        protected void SeedMasterAdmin(ModelBuilder builder)
        {
            string masterUsername = _config["masterUsername"];
            string masterPassword = _config["masterPassword"];

            IdentityUser masterUser = new IdentityUser();
            masterUser.Id = "master1";
            masterUser.Email = masterUsername;
            masterUser.NormalizedUserName = masterUsername.ToUpper();
            masterUser.UserName = masterUsername;
            masterUser.NormalizedEmail = masterUsername.ToUpper();
            masterUser.EmailConfirmed = true;
            masterUser.PasswordHash = new PasswordHasher<IdentityUser>().HashPassword(masterUser, masterPassword);

            UserDataModel masterData = new UserDataModel() { Id = masterUser.Id, IsMaster = true, IsAdmin = true };

            builder.Entity<IdentityUser>().HasData(masterUser);
            builder.Entity<UserDataModel>().HasData(masterData);
        }
    }
}