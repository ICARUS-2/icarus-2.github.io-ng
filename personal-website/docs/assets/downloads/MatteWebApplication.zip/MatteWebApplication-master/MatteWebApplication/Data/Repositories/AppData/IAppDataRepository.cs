﻿using MatteWebApplication.Models.Communication;
using MatteWebApplication.Models.Store;

namespace MatteWebApplication.Data.Repositories.AppData
{
    /// <summary>
    /// Generic interface used for interacting with a storefront's database.
    /// </summary>
    public interface IAppDataRepository
    {
        //category

        /// <summary>
        /// Asynchronously adds a new category to the database.
        /// </summary>
        /// <param name="category">The category to be added.</param>
        /// <returns>True/False based on the success of the operation.</returns>
        public Task<bool> AddCategoryAsync(Category category);

        /// <summary>
        /// Asynchronously retrieves the list of all categories in the database.
        /// </summary>
        /// <returns>The list of all of the store's categories.</returns>
        public Task<List<Category>> GetCategoriesListAsync();

        /// <summary>
        /// Asynchronously retrieves a category based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the category we are looking for.</param>
        /// <returns>The category if it exists, null if not.</returns>
        public Task<Category> GetCategoryByIdAsync(int id);

        /// <summary>
        /// Takes a category and updates its data in the database.
        /// </summary>
        /// <param name="category">The category containing the updated data.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> UpdateCategoryAsync(Category category);

        /// <summary>
        /// Deletes a category and the products associated with it from the database.
        /// </summary>
        /// <param name="categoryId">The ID of the category that will be deleted alongside its products.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> DeleteCategoryAndProductsAsync(int id);

        //product

        /// <summary>
        /// Asynchronously retrieves the list of products in the database.
        /// </summary>
        /// <returns>The list of all the store's products.</returns>
        public Task<List<Product>> GetProductsListAsync();

        /// <summary>
        /// Asynchronously retrieves a product's data based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the product whose data is needed.</param>
        /// <returns>The product object if it exists, null if not.</returns>
        public Task<Product> GetProductByIdAsync(int id);

        /// <summary>
        /// Asynchronously gets all of the products for a given category.
        /// </summary>
        /// <param name="categoryId">The category whose products we are searching for.</param>
        /// <returns>The list of products if the category exists, an empty list if the category has no products, or null if the category does not exist.</returns>
        public Task<List<Product>> GetProductsByCategoryAsync(int categoryId);

        /// <summary>
        /// Asynchronously gets all of the products that are listed as best sellers.
        /// </summary>
        /// <returns>A list of all of the best sellers</returns>
        public Task<List<Product>> GetBestSellerProductsAsync();

        /// <summary>
        /// Asynchronously gets all of the products marked as featured.
        /// </summary>
        /// <returns>A list of all featured products.</returns>
        public Task<List<Product>> GetFeaturedProductsAsync();

        /// <summary>
        /// Asynchrounously gets all of the products marked as new arrivals.
        /// </summary>
        /// <returns>A list of all new arrival products.</returns>
        public Task<List<Product>> GetNewArrivalProductsAsync();


        /// <summary>
        /// Asynchronously creates a new product entry in the database.
        /// </summary>
        /// <param name="product">The product that will be added to the database.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> CreateProductAsync(Product product);

        /// <summary>
        /// Asynchronously updates an existing product's data in the database.
        /// </summary>
        /// <param name="product">The product containing the data that will be updated.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> UpdateProductAsync(Product product);

        /// <summary>
        /// Asynchronously deletes a product based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the product that will be deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> DeleteProductAsync(int id);

        //image data
        /// <summary>
        /// Asynchronously adds new image data to the database.
        /// </summary>
        /// <param name="img">The image data that will be added.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> CreateStoreImageDataAsync(StoreImage img);

        /// <summary>
        /// Asynchronously retrieves a product's imaage data based on the passed product ID.
        /// </summary>
        /// <param name="productId">The ID of the product whose images we are looking for.</param>
        /// <returns>The list of images for that product.</returns>
        public Task<List<StoreImage>> GetStoreImagesByProductIdAsync(int productId);

        /// <summary>
        /// Asynchronously retrieves a single store image based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the image we are searching for.</param>
        /// <returns>The image data if it exists, null if not.</returns>
        public Task<StoreImage> GetStoreImageByIdAsync(int id);

        /// <summary>
        /// Asynchronously deletes a store image in the database based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the image being deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> DeleteStoreImageByIdAsync(int id);

        /// <summary>
        /// Asynchronously deletes all of a product's images in the database.
        /// </summary>
        /// <param name="productId">The ID of the product whose images will be deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> DeleteAllProductImageDataAsync(int productId);

        //contact receivers

        /// <summary>
        /// Asynchronously retrieves the list of all contact receivers in the database.
        /// </summary>
        /// <returns>The list of all existing contact receivers.</returns>
        public Task<List<ContactReceiverModel>> GetContactReceiversAsync();

        /// <summary>
        /// Creates new contact receiver entry in the database.
        /// </summary>
        /// <param name="contactReceiverModel">The data of the contact receiver that will be added.</param>
        /// <returns>True/false based on the result of the operation</returns>
        public Task<bool> CreateContactReceiverAsync(ContactReceiverModel contactReceiverModel);

        /// <summary>
        /// Asynchronously retrieves contact receiver data associated with the passed ID.
        /// </summary>
        /// <param name="id">The ID of the contact receiver whose data will be retrieved.</param>
        /// <returns>The contact data if it exists, null if it does not.</returns>
        public Task<ContactReceiverModel> GetContactReceiverByIdAsync(int id);

        /// <summary>
        /// Asynchronously deletes a contact receiver's data associated with the passed ID.
        /// </summary>
        /// <param name="id">The ID of the contact receiver whose data will be deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> DeleteContactReceiverAsync(int id);

        //Sale timer

        /// <summary>
        /// Asynchronously creates a new SaleTimerModel in the database.
        /// </summary>
        /// <param name="saleTimerModel">The model to be added in the database.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> CreateSaleTimerAsync(SaleTimerModel saleTimerModel);

        /// <summary>
        /// Asynchronously gets a list of all sale timers.
        /// </summary>
        /// <returns>A list of all SaleTimers in the database</returns>
        public Task<List<SaleTimerModel>> GetSaleTimersListAsync();

        /// <summary>
        /// Asynchronously gets a sale timer from the database by its ID.
        /// </summary>
        /// <param name="id">The ID of the sale timer to be retrieved.</param>
        /// <returns>The sale timer if it exists, null if it does not.</returns>
        public Task<SaleTimerModel> GetSaleTimerByIdAsync(int id);

        /// <summary>
        /// Asynchronously deletes a sale timer by ID.
        /// </summary>
        /// <param name="id">The ID of the sale timer to be deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> DeleteSaleTimerAsync(int id);

        /// <summary>
        /// Asynchronously creates a new review for a product with a given ID.
        /// </summary>
        /// <param name="review">The review to be added.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> CreateReviewAsync(Review review);

        /// <summary>
        /// Asynchronously gets a review based on its ID.
        /// </summary>
        /// <param name="id">The review ID.</param>
        /// <returns>The review associated with the ID.</returns>
        public Task<Review> GetReviewByIdAsync(int id);

        /// <summary>
        /// Asynchronously takes a review and updates it.
        /// </summary>
        /// <param name="review">The review to be updated.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> UpdateReviewAsync(Review review);

        /// <summary>
        /// Asynchronously deletes a review based on the passed ID.
        /// </summary>
        /// <param name="id">The ID of the review to be deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> DeleteReviewAsync(int id);

        /// <summary>
        /// Asynchronously retrieves a list of reviews for a given product.
        /// </summary>
        /// <param name="productId">The ID of the product whose reviews will be retrieved.</param>
        /// <returns>The list of reviews for that product.</returns>
        public Task<List<Review>> GetReviewsForProductAsync(int productId);

        /// <summary>
        /// Asynchronously deletes all of a given product's reviews.
        /// </summary>
        /// <param name="productId">The ID of the product whose reviews will be deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> DeleteReviewsForProductAsync(int productId);
    }
}
