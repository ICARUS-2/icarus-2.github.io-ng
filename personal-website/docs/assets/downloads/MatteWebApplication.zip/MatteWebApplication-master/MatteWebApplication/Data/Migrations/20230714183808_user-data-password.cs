﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MatteWebApplication.Data.Migrations
{
    public partial class userdatapassword : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "abc1ffdd-2906-449b-813a-ca8326d0f627", "AQAAAAEAACcQAAAAEOEfMODHL8CyN9ysu9FlTgjA1JYME9/SLLhxBwS58HhU7kQpcJ8ymOEfS6AVwme+6A==", "8597f538-0726-49fa-aec2-816c73313595" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "f8baafc5-b6b8-4a1b-a248-47bd0b3a8c9d", "AQAAAAEAACcQAAAAEOB//7s7BmrxfMvNHpgEbS6BFaGRfgwXU4d/f7ayVK4oUkcKMiceVLZW3N0+ILDPOQ==", "591b787e-6029-48f1-82ed-1751a1e1f6e2" });
        }
    }
}
