﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MatteWebApplication.Data.Migrations
{
    public partial class PromotionalEmailSubscribe : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsPromotionalSubscribed",
                table: "UserDataModels",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "b370596f-791d-4eef-9999-b7f675e9b80b", "AQAAAAEAACcQAAAAEA/DRxcwZP2+u+1SGK6VwGVyePJEUAinf2FK1Xe1JcnyPFlhOuxdWOBPiC/4qcr/ig==", "50cc5e1f-93ae-47c0-a37a-3b1cc38f9124" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsPromotionalSubscribed",
                table: "UserDataModels");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "abc1ffdd-2906-449b-813a-ca8326d0f627", "AQAAAAEAACcQAAAAEOEfMODHL8CyN9ysu9FlTgjA1JYME9/SLLhxBwS58HhU7kQpcJ8ymOEfS6AVwme+6A==", "8597f538-0726-49fa-aec2-816c73313595" });
        }
    }
}
