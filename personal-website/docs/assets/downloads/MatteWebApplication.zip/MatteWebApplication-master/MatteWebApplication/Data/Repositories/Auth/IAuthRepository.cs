﻿using MatteWebApplication.Models.User;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace MatteWebApplication.Data.Repositories.Auth
{
    /// <summary>
    /// Generic interface used to interact with a database of IdentityUsers and associated UserDataModels.
    /// </summary>
    public interface IAuthRepository
    {
        /// <summary>
        /// Asynchronously adds new user data to the database.
        /// </summary>
        /// <param name="model">The user data that will be added.</param>
        /// <returns>The async task</returns>
        public Task CreateUserDataAsync(UserDataModel model);

        /// <summary>
        /// Asynchronously retrieves the user from the database associated with the passed ID.
        /// </summary>
        /// <param name="id">The ID of the user that will be retrieved.</param>
        /// <returns>The IdentityUser with that ID if it exists, or null if not.</returns>
        public Task<IdentityUser> GetIdentityUserByIdAsync(string id);

        /// <summary>
        /// Asynchronously retrieves a user's data associated with the passed ID.
        /// </summary>
        /// <param name="id">The ID of the user whose data will be retrieved.</param>
        /// <returns>The user data associated with that ID if it exists, null if it does not.</returns>
        public Task<UserDataModel> GetUserDataByIdAsync(string id);

        /// <summary>
        /// Asynchronously deletes a user's data.
        /// </summary>
        /// <param name="userId">ID of the user whose data is being deleted.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> DeleteUserDataAsync(string userId);

        /// <summary>
        /// Retrieves a list of all existing users.
        /// </summary>
        /// <returns>The list of all existing IdentityUsers</returns>
        public Task<List<IdentityUser>> GetUsersAsync();

        //roles

        /// <summary>
        /// Asynchronously updates a user's admin status in the database.
        /// </summary>
        /// <param name="userId">The user whose status will be updated.</param>
        /// <param name="isAdmin">True if granting admin permissions, false if revoking them.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> UpdateUserAdminStatusAsync(string userId, bool isAdmin);

        /// <summary>
        /// ASynchronously sets a user's ban status in the database.
        /// </summary>
        /// <param name="userId">The ID of the user whose ban status will be updated.</param>
        /// <param name="willBan">True if banning, false if unbanning.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> SetUserBanStatusAsync(string userId, bool isBanned);

        /// <summary>
        /// Tells whether a given user is an admin or not.
        /// </summary>
        /// <param name="user">The user object.</param>
        /// <param name="userManager">The user manager that will check its status.</param>
        /// <returns>True if user is admin, false if not.</returns>
        public Task<bool> UserIsAdminAsync(ClaimsPrincipal user, UserManager<IdentityUser> userManager);

        /// <summary>
        /// Tells whether a given user is a webmaster or not.
        /// </summary>
        /// <param name="user">The user object.</param>
        /// <param name="userManager">The user manager that will check its status.</param>
        /// <returns>True if user is webmaster, false if not.</returns>
        public Task<bool> UserIsMasterAsync(ClaimsPrincipal user, UserManager<IdentityUser> userManager);

        /// <summary>
        /// Tells whether a given user is an admin, a webmaster, or neither.
        /// </summary>
        /// <param name="user">The user object.</param>
        /// <param name="userManager">The user manager that will check its status.</param>
        /// <returns>True if user is either an admin or webmaster, false if the user is neither.</returns>
        public Task<bool> UserIsMasterOrAdminAsync(ClaimsPrincipal user, UserManager<IdentityUser> userManager);

        /// <summary>
        /// Sets the promotional email subscription status for a user.
        /// </summary>
        /// <param name="userId">The user to be modified.</param>
        /// <param name="shouldSubscribe">True if subscribing, false if unsubscribing.</param>
        /// <returns>True/false based on the result of the operation.</returns>
        public Task<bool> SetUserPromotionalSubscriptionAsync(string userId, bool shouldSubscribe);

        /// <summary>
        /// Gets the list of users subscribed to promotional marketing emails.
        /// </summary>
        /// <returns>List of all promotional-subscribed users.</returns>
        public Task<List<IdentityUser>> GetPromotionalMailingListAsync();
    }
}
