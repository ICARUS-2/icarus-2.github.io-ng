﻿using Microsoft.AspNetCore.Identity.UI.Services;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace MatteWebApplication.Data
{
    /// <summary>
    /// SMTP sender that sends emails through Google's SMTP server using injected credentials.
    /// </summary>
    public class GoogleSMTPSender : IEmailSender
    {
        private readonly IConfiguration _config;

        /// <summary>
        /// Uses an injected IConfiguration instance to configure the SMTP sender.
        /// </summary>
        /// <param name="config">Injected IConfiguration containing the GMail credentials (See secrets-template.json)</param>
        public GoogleSMTPSender(IConfiguration config)
        {
            _config = config;
        }

        /// <summary>
        /// Asynchronously sends an email through Google's SMTP server using the credentials from the injected IConfiguration instance
        /// </summary>
        /// <param name="email">The receiver of the email.</param>
        /// <param name="subject">The email's subject.</param>
        /// <param name="htmlMessage">The body of the email.</param>
        /// <returns>The Task to be awaited.</returns>
        public async Task SendEmailAsync(string email, string subject, string htmlMessage)
        {
            string username = _config["emailSenderUsername"];
            string password = _config["emailSenderPassword"];

            SmtpClient smtpClient = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                Credentials = new NetworkCredential(username, password)
            };

            MailMessage mailMessage = new MailMessage
            {
                From = new MailAddress(username),
                Subject = subject,
                Body = htmlMessage
            };

            mailMessage.To.Add(email);

            await smtpClient.SendMailAsync(mailMessage);
        }
    }
}
