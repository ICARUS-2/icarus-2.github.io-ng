﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MatteWebApplication.Data.Migrations
{
    public partial class SeedMasterRole2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1",
                columns: new[] { "ConcurrencyStamp", "NormalizedUserName", "PasswordHash", "SecurityStamp", "UserName" },
                values: new object[] { "c191106e-9305-4cb5-a22d-9099e79b8da8", "EBRIFFETT01@GMAIL.COM", "AQAAAAEAACcQAAAAEAC4SGj/5wmw/UapBAmGnw6wK88pzywGw0MNUw5IdL1qdPyKxp/D2hNNohQKb8hfYg==", "2dbd2ed0-f3a9-45d6-abec-482e6c445c4c", "ebriffett01@gmail.com" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1",
                columns: new[] { "ConcurrencyStamp", "NormalizedUserName", "PasswordHash", "SecurityStamp", "UserName" },
                values: new object[] { "2c0674d7-2bc3-4605-8044-484c9f8f2231", null, "AQAAAAEAACcQAAAAEOe6Y2ENXZpjr8lCRjClqqOpTw2qOw+lWLHBZr/Pl7H1Z8Ra4ZLAxF/8AogHiTrEkQ==", "5440c0ea-d94c-49df-89d9-12e80cfdb781", "Master" });
        }
    }
}
