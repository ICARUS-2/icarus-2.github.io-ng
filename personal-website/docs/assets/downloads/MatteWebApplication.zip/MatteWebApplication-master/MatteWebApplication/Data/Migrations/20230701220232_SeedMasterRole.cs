﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MatteWebApplication.Data.Migrations
{
    public partial class SeedMasterRole : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName" },
                values: new object[] { "master1", 0, "2c0674d7-2bc3-4605-8044-484c9f8f2231", "ebriffett01@gmail.com", true, false, null, null, null, "AQAAAAEAACcQAAAAEOe6Y2ENXZpjr8lCRjClqqOpTw2qOw+lWLHBZr/Pl7H1Z8Ra4ZLAxF/8AogHiTrEkQ==", null, false, "5440c0ea-d94c-49df-89d9-12e80cfdb781", false, "Master" });

            migrationBuilder.InsertData(
                table: "UserDataModels",
                columns: new[] { "Id", "IsAdmin", "IsMaster" },
                values: new object[] { "master1", true, true });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "master1");

            migrationBuilder.DeleteData(
                table: "UserDataModels",
                keyColumn: "Id",
                keyValue: "master1");
        }
    }
}
